<?php
dl("dgbaopro");
function def($b){
$b = json_decode($b,true);
echo "def start:".microtime(true)."\n";
print_r($b);
sleep(6);
echo "def done:".microtime(true)."\n";
echo "function def done\n";
}
function abc(){
echo "abc start:".microtime(true)."\n";
//$a = json_decode($a,true);
//print_r($a);
sleep(4);
echo "abc done:".microtime(true)."\n";
echo "function abc done\n";
}
$param = [];
$param["a"] = "var a";
$param["b"] = "var b";
$params = json_encode($param);
if(Dgbaopro\Vip::login("dichvucoder-KEY.AUTH.VIP-HK77180118920011557801990118222AAJJSOWOWKWPO3993O3")){
}else{
print(Dgbaopro\Vip::$error);die;
}
Dgbaopro\Vip::addstream("abc"); //Không Khóa Vào luồng này
//Dgbaopro\Vip::exitstream(0);
Dgbaopro\Vip::addstream("def",$params); // Khóa Vô Luồng Này
//sleep(7);
//echo "abc";
sleep(7);
