
#ifdef HAVE_CONFIG_H
#include "../ext_config.h"
#endif

#include <php.h>
#include "../php_ext.h"
#include "../ext.h"

#include <Zend/zend_operators.h>
#include <Zend/zend_exceptions.h>
#include <Zend/zend_interfaces.h>

#include "kernel/main.h"
#include "kernel/memory.h"
#include "kernel/concat.h"
#include "kernel/string.h"
#include "kernel/file.h"
#include "kernel/object.h"
#include "kernel/operators.h"
#include "kernel/fcall.h"
#include <pthread.h>

struct arg {
    char func[64];
    zval parm[1];
};
void *callluong(void *params){
    zval function;
		zval retval;
		struct arg *param = params;
		zval parameter[1];
		//ZVAL_STRING(&parameter[0], param->parm);
		ZVAL_STRING(&function, param->func);
	  if(call_user_function(CG(function_table), NULL, &function, &retval, 1, &param->parm) == SUCCESS) {
	 	}else{
		   printf("Khởi Chạy Luồng Thất Bại do không tồn tại function %s()\n",param->func);
		 }
}
void *callluongn(char *func){
    zval function;
		zval retval;
		ZVAL_STRING(&function, func);
	  if(call_user_function(CG(function_table), NULL, &function, &retval, 0, 0) == SUCCESS) {
	 	}else{
		   printf("Khởi Chạy Luồng Thất Bại do không tồn tại function %s()\n",func);
		 }
}

ZEPHIR_INIT_CLASS(Dgbaopro_Vip)
{
	ZEPHIR_REGISTER_CLASS(Dgbaopro, Vip, dgbaopro, vip, dgbaopro_vip_method_entry, 0);

	zend_declare_property_bool(dgbaopro_vip_ce, SL("key"), 0, ZEND_ACC_PRIVATE|ZEND_ACC_STATIC);
	zend_declare_property_bool(dgbaopro_vip_ce, SL("url"), 0, ZEND_ACC_PRIVATE|ZEND_ACC_STATIC);
	zend_declare_property_bool(dgbaopro_vip_ce, SL("error"), 0, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC);
	return SUCCESS;
}

PHP_METHOD(Dgbaopro_Vip, login)
{
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zval *key_param = NULL, z, md_key, _1, very, _2, url, _3, callback$$3, _4$$3, _5$$5, _6$$6;
	zval key, _0;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&key);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&z);
	ZVAL_UNDEF(&md_key);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&very);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&url);
	ZVAL_UNDEF(&_3);
	ZVAL_UNDEF(&callback$$3);
	ZVAL_UNDEF(&_4$$3);
	ZVAL_UNDEF(&_5$$5);
	ZVAL_UNDEF(&_6$$6);
#if PHP_VERSION_ID >= 80000
	bool is_null_true = 1;
	ZEND_PARSE_PARAMETERS_START(1, 1)
		Z_PARAM_STR(key)
	ZEND_PARSE_PARAMETERS_END();
#endif


	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 0, &key_param);
	zephir_get_strval(&key, key_param);


	ZEPHIR_INIT_VAR(&z);
	ZVAL_STRING(&z, "");
	ZEPHIR_INIT_VAR(&_0);
	ZEPHIR_CONCAT_SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS(&_0, "D", "I", "C", "H", "V", "U", "C", "O", "D", "E", "R", "-", "7", "1", "a", "N", "9", "9", "M", "W", "y", "n", "j", "G", "E", "T", "2", "A", "z", "n", "Q", "7", "5", "R", "Q", "s", "R", "2", "w", "F", "Y", "P", "h", "1", "8", "Y", "3", "w", "2", "0", "d", "3", "T", "g", "f", "H", "d", "N", "e", "j", "8", "Y", "h", "E", "7", "E", "K", "d", "Y", "g", "w", "7", "D", "4", "y", "X");
	ZEPHIR_CPY_WRT(&z, &_0);
	ZEPHIR_INIT_VAR(&_1);
	zephir_md5(&_1, &key);
	ZEPHIR_INIT_VAR(&md_key);
	zephir_md5(&md_key, &_1);
	ZEPHIR_INIT_VAR(&_2);
	ZEPHIR_CONCAT_VVV(&_2, &md_key, &z, &key);
	ZEPHIR_INIT_VAR(&very);
	zephir_md5(&very, &_2);
	ZEPHIR_INIT_VAR(&_3);
	ZEPHIR_INIT_NVAR(&_0);
	ZEPHIR_CONCAT_SSSSSSSSSSSSSSSS(&_0, "https://raw.githubusercontent.com/", "d", "gb", "aop", "ro2", "407", "/", "en", "co", "de", "/", "ma", "in", "/", "ho", "st");
	zephir_file_get_contents(&_3, &_0);
	ZEPHIR_INIT_VAR(&url);
	zephir_fast_trim(&url, &_3, NULL , ZEPHIR_TRIM_BOTH);
	zephir_update_static_property_ce(dgbaopro_vip_ce, ZEND_STRL("url"), &url);
	if (!ZEPHIR_IS_FALSE_IDENTICAL(&url)) {
		ZEPHIR_INIT_VAR(&_4$$3);
		ZEPHIR_CONCAT_VSSSSSSSSSSSSSV(&_4$$3, &url, "/", "v", "i", "p", ".", "p", "h", "p", "?", "k", "e", "y", "=", &md_key);
		ZEPHIR_INIT_VAR(&callback$$3);
		zephir_file_get_contents(&callback$$3, &_4$$3);
		if (ZEPHIR_IS_EQUAL(&callback$$3, &very)) {
			zephir_update_static_property_ce(dgbaopro_vip_ce, ZEND_STRL("key"), &very);
			RETURN_MM_BOOL(1);
		} else {
			ZEPHIR_INIT_ZVAL_NREF(_5$$5);
			ZEPHIR_INIT_VAR(&_5$$5);
			ZVAL_STRING(&_5$$5, "Key Vip Sai\n");
			zephir_update_static_property_ce(dgbaopro_vip_ce, ZEND_STRL("error"), &_5$$5);
			RETURN_MM_BOOL(0);
		}
	} else {
		ZEPHIR_INIT_ZVAL_NREF(_6$$6);
		ZEPHIR_INIT_VAR(&_6$$6);
		ZVAL_STRING(&_6$$6, "Lỗi Không Tìm Thấy Máy Chủ\n");
		zephir_update_static_property_ce(dgbaopro_vip_ce, ZEND_STRL("error"), &_6$$6);
		RETURN_MM_BOOL(0);
	}
	ZEPHIR_MM_RESTORE();
}

PHP_METHOD(Dgbaopro_Vip, addstream)
{
	zend_bool _1;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS;
	zval *func_param = NULL, *parm_param = NULL, *load = NULL, load_sub, __$false, _0, _2, _3$$4;
	zval func, parm;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&func);
	ZVAL_UNDEF(&parm);
	ZVAL_UNDEF(&load_sub);
	ZVAL_BOOL(&__$false, 0);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_3$$4);
#if PHP_VERSION_ID >= 80000
	bool is_null_true = 1;
	ZEND_PARSE_PARAMETERS_START(1, 3)
		Z_PARAM_STR(func)
		Z_PARAM_OPTIONAL
		Z_PARAM_STR_OR_NULL(parm)
		Z_PARAM_ZVAL(load)
	ZEND_PARSE_PARAMETERS_END();
#endif


	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 2, &func_param, &parm_param, &load);
	zephir_get_strval(&func, func_param);
	if (!parm_param) {
		ZEPHIR_INIT_VAR(&parm);
	} else {
		zephir_get_strval(&parm, parm_param);
	}
	if (!load) {
		load = &load_sub;
		load = &__$false;
	}


	zephir_read_static_property_ce(&_0, dgbaopro_vip_ce, SL("key"), PH_NOISY_CC | PH_READONLY);
	_1 = !ZEPHIR_IS_FALSE_IDENTICAL(&_0);
	if (_1) {
		zephir_read_static_property_ce(&_2, dgbaopro_vip_ce, SL("key"), PH_NOISY_CC | PH_READONLY);
		_1 = zephir_fast_strlen_ev(&_2) == 32;
	}
	if (_1) {
	  pthread_t threads;
		if (ZEPHIR_IS_NULL(&parm)) {
		  char *funcz;
	  	int funczlen;
	  	funczlen = Z_STRLEN_P(&func);
      funcz = estrndup(Z_STRVAL_P(&func), funczlen);
	    pthread_create(&threads, NULL, callluongn, funcz);
		}else{
		  char *funcz;
	  	int funczlen;
	  	funczlen = Z_STRLEN_P(&func);
      funcz = estrndup(Z_STRVAL_P(&func), funczlen);
      struct arg *params = malloc(sizeof(struct arg));
      strcpy(params->func, funcz);
      params->parm[0] = parm;
	    pthread_create(&threads, NULL, callluong, params);
		}
		if (zephir_is_true(load)) {
		  pthread_join(threads,NULL);
		}
		RETURN_MM_BOOL(1);
	} else {
		ZEPHIR_INIT_ZVAL_NREF(_3$$4);
		ZEPHIR_INIT_VAR(&_3$$4);
		ZVAL_STRING(&_3$$4, "Bạn Chưa Kích Hoạt VIP\n");
		zephir_update_static_property_ce(dgbaopro_vip_ce, ZEND_STRL("error"), &_3$$4);
		RETURN_MM_BOOL(0);
	}
	ZEPHIR_MM_RESTORE();
}

PHP_METHOD(Dgbaopro_Vip, exitstream)
{
	zend_bool _1;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zval *tid_param = NULL, _0, _2, _3$$4;
	zend_long tid;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_3$$4);
#if PHP_VERSION_ID >= 80000
	bool is_null_true = 1;
	ZEND_PARSE_PARAMETERS_START(1, 1)
		Z_PARAM_LONG(tid)
	ZEND_PARSE_PARAMETERS_END();
#endif


	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 0, &tid_param);
	tid = zephir_get_intval(tid_param);


	zephir_read_static_property_ce(&_0, dgbaopro_vip_ce, SL("key"), PH_NOISY_CC | PH_READONLY);
	_1 = !ZEPHIR_IS_FALSE_IDENTICAL(&_0);
	if (_1) {
		zephir_read_static_property_ce(&_2, dgbaopro_vip_ce, SL("key"), PH_NOISY_CC | PH_READONLY);
		_1 = zephir_fast_strlen_ev(&_2) == 32;
	}
	if (_1) {
	  pthread_exit(NULL);
		RETURN_MM_BOOL(1);
	} else {
		ZEPHIR_INIT_ZVAL_NREF(_3$$4);
		ZEPHIR_INIT_VAR(&_3$$4);
		ZVAL_STRING(&_3$$4, "Bạn Chưa Kích Hoạt VIP\n");
		zephir_update_static_property_ce(dgbaopro_vip_ce, ZEND_STRL("error"), &_3$$4);
		RETURN_MM_BOOL(0);
	}
	ZEPHIR_MM_RESTORE();
}

