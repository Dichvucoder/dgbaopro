
extern zend_class_entry *dgbaopro_vip_ce;

ZEPHIR_INIT_CLASS(Dgbaopro_Vip);

PHP_METHOD(Dgbaopro_Vip, login);
PHP_METHOD(Dgbaopro_Vip, addstream);
PHP_METHOD(Dgbaopro_Vip, exitstream);

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_vip_login, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, key, IS_STRING, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_vip_addstream, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, func, IS_STRING, 0)
	ZEND_ARG_TYPE_INFO(0, parm, IS_STRING, 1)
	ZEND_ARG_INFO(0, load)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_vip_exitstream, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, tid, IS_LONG, 0)
ZEND_END_ARG_INFO()

ZEPHIR_INIT_FUNCS(dgbaopro_vip_method_entry) {
	PHP_ME(Dgbaopro_Vip, login, arginfo_dgbaopro_vip_login, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(Dgbaopro_Vip, addstream, arginfo_dgbaopro_vip_addstream, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(Dgbaopro_Vip, exitstream, arginfo_dgbaopro_vip_exitstream, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_FE_END
};
