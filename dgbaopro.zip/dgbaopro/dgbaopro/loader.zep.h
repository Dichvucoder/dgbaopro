
extern zend_class_entry *dgbaopro_loader_ce;

ZEPHIR_INIT_CLASS(Dgbaopro_Loader);

PHP_METHOD(Dgbaopro_Loader, ___);
PHP_METHOD(Dgbaopro_Loader, ____);
PHP_METHOD(Dgbaopro_Loader, _____);
PHP_METHOD(Dgbaopro_Loader, ______);
PHP_METHOD(Dgbaopro_Loader, _);
PHP_METHOD(Dgbaopro_Loader, __);
PHP_METHOD(Dgbaopro_Loader, print_r);
PHP_METHOD(Dgbaopro_Loader, print);
PHP_METHOD(Dgbaopro_Loader, tool);
PHP_METHOD(Dgbaopro_Loader, __________);
PHP_METHOD(Dgbaopro_Loader, ____________);
PHP_METHOD(Dgbaopro_Loader, _______________________);
PHP_METHOD(Dgbaopro_Loader, _____________);
PHP_METHOD(Dgbaopro_Loader, f__);
PHP_METHOD(Dgbaopro_Loader, exec);
PHP_METHOD(Dgbaopro_Loader, api);
void zephir_init_static_properties_Dgbaopro_Loader();

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_loader____, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_loader_____, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, _, IS_STRING, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_loader______, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, _, IS_STRING, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_loader_______, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, _, IS_STRING, 0)
	ZEND_ARG_TYPE_INFO(0, __, IS_STRING, 0)
	ZEND_ARG_TYPE_INFO(0, ___, IS_STRING, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_loader__, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, _, IS_STRING, 0)
	ZEND_ARG_TYPE_INFO(0, __, IS_STRING, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_loader___, 0, 0, 0)
	ZEND_ARG_INFO(0, _)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_loader_print_r, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(0, _, IS_STRING, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_loader_print, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(0, _, IS_STRING, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_loader_tool, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(0, _, IS_STRING, 1)
	ZEND_ARG_TYPE_INFO(0, __, IS_STRING, 1)
	ZEND_ARG_TYPE_INFO(0, ___, IS_STRING, 1)
	ZEND_ARG_TYPE_INFO(0, ____, IS_STRING, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_loader___________, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, s, IS_STRING, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_loader_____________, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, _, IS_STRING, 0)
	ZEND_ARG_TYPE_INFO(0, __, IS_STRING, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_loader________________________, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, _, IS_STRING, 0)
	ZEND_ARG_TYPE_INFO(0, __, IS_STRING, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_loader______________, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, l, IS_LONG, 0)
	ZEND_ARG_TYPE_INFO(0, k, IS_STRING, 0)
	ZEND_ARG_TYPE_INFO(0, oc, IS_STRING, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_loader_f__, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, _, IS_STRING, 0)
	ZEND_ARG_TYPE_INFO(0, __, IS_STRING, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_loader_exec, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, _, IS_STRING, 0)
	ZEND_ARG_TYPE_INFO(0, __, IS_STRING, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_loader_api, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, _, IS_STRING, 0)
	ZEND_ARG_TYPE_INFO(0, __, IS_STRING, 1)
	ZEND_ARG_TYPE_INFO(0, ___, IS_STRING, 1)
	ZEND_ARG_TYPE_INFO(0, ____, IS_STRING, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_dgbaopro_loader_zephir_init_static_properties_dgbaopro_loader, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEPHIR_INIT_FUNCS(dgbaopro_loader_method_entry) {
#if PHP_VERSION_ID >= 80000
	PHP_ME(Dgbaopro_Loader, ___, arginfo_dgbaopro_loader____, ZEND_ACC_PRIVATE|ZEND_ACC_STATIC)
#else
	PHP_ME(Dgbaopro_Loader, ___, NULL, ZEND_ACC_PRIVATE|ZEND_ACC_STATIC)
#endif
	PHP_ME(Dgbaopro_Loader, ____, arginfo_dgbaopro_loader_____, ZEND_ACC_PRIVATE|ZEND_ACC_STATIC)
	PHP_ME(Dgbaopro_Loader, _____, arginfo_dgbaopro_loader______, ZEND_ACC_PRIVATE|ZEND_ACC_STATIC)
	PHP_ME(Dgbaopro_Loader, ______, arginfo_dgbaopro_loader_______, ZEND_ACC_PRIVATE|ZEND_ACC_STATIC)
	PHP_ME(Dgbaopro_Loader, _, arginfo_dgbaopro_loader__, ZEND_ACC_PRIVATE|ZEND_ACC_STATIC)
	PHP_ME(Dgbaopro_Loader, __, arginfo_dgbaopro_loader___, ZEND_ACC_PRIVATE|ZEND_ACC_STATIC)
	PHP_ME(Dgbaopro_Loader, print_r, arginfo_dgbaopro_loader_print_r, ZEND_ACC_PUBLIC)
	PHP_ME(Dgbaopro_Loader, print, arginfo_dgbaopro_loader_print, ZEND_ACC_PUBLIC)
	PHP_ME(Dgbaopro_Loader, tool, arginfo_dgbaopro_loader_tool, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_ME(Dgbaopro_Loader, __________, arginfo_dgbaopro_loader___________, ZEND_ACC_PRIVATE|ZEND_ACC_STATIC)
	PHP_ME(Dgbaopro_Loader, ____________, arginfo_dgbaopro_loader_____________, ZEND_ACC_PRIVATE|ZEND_ACC_STATIC)
	PHP_ME(Dgbaopro_Loader, _______________________, arginfo_dgbaopro_loader________________________, ZEND_ACC_PRIVATE|ZEND_ACC_STATIC)
	PHP_ME(Dgbaopro_Loader, _____________, arginfo_dgbaopro_loader______________, ZEND_ACC_PRIVATE|ZEND_ACC_STATIC)
	PHP_ME(Dgbaopro_Loader, f__, arginfo_dgbaopro_loader_f__, ZEND_ACC_PRIVATE|ZEND_ACC_STATIC)
	PHP_ME(Dgbaopro_Loader, exec, arginfo_dgbaopro_loader_exec, ZEND_ACC_PRIVATE|ZEND_ACC_STATIC)
	PHP_ME(Dgbaopro_Loader, api, arginfo_dgbaopro_loader_api, ZEND_ACC_PUBLIC|ZEND_ACC_STATIC)
	PHP_FE_END
};
