
/* This file was generated automatically by Zephir do not modify it! */

#ifndef PHP_DGBAOPRO_H
#define PHP_DGBAOPRO_H 1

#ifdef PHP_WIN32
#define ZEPHIR_RELEASE 1
#endif

#include "kernel/globals.h"

#define PHP_DGBAOPRO_NAME        "dgbaopro"
#define PHP_DGBAOPRO_VERSION     "8.5.1"
#define PHP_DGBAOPRO_EXTNAME     "dgbaopro"
#define PHP_DGBAOPRO_AUTHOR      "Dgbaopro Team"
#define PHP_DGBAOPRO_DESCRIPTION ""



ZEND_BEGIN_MODULE_GLOBALS(dgbaopro)

	int initialized;

	/** Function cache */
	HashTable *fcache;

	zephir_fcall_cache_entry *scache[ZEPHIR_MAX_CACHE_SLOTS];

	/* Cache enabled */
	unsigned int cache_enabled;

	/* Max recursion control */
	unsigned int recursive_lock;

	
ZEND_END_MODULE_GLOBALS(dgbaopro)

#ifdef ZTS
#include "TSRM.h"
#endif

ZEND_EXTERN_MODULE_GLOBALS(dgbaopro)

#ifdef ZTS
	#define ZEPHIR_GLOBAL(v) ZEND_MODULE_GLOBALS_ACCESSOR(dgbaopro, v)
#else
	#define ZEPHIR_GLOBAL(v) (dgbaopro_globals.v)
#endif

#ifdef ZTS
	ZEND_TSRMLS_CACHE_EXTERN()
	#define ZEPHIR_VGLOBAL ((zend_dgbaopro_globals *) (*((void ***) tsrm_get_ls_cache()))[TSRM_UNSHUFFLE_RSRC_ID(dgbaopro_globals_id)])
#else
	#define ZEPHIR_VGLOBAL &(dgbaopro_globals)
#endif

#define ZEPHIR_API ZEND_API

#define zephir_globals_def dgbaopro_globals
#define zend_zephir_globals_def zend_dgbaopro_globals

extern zend_module_entry dgbaopro_module_entry;
#define phpext_dgbaopro_ptr &dgbaopro_module_entry

#endif
