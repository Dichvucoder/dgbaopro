<?php
$test = new dgbaopro\loader;
$test->data("_________","hsjdhdh");
