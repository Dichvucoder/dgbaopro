<?php
dgbaopro\loader::tool("______",trim(fgets(STDIN)),trim(fgets(STDIN)));
