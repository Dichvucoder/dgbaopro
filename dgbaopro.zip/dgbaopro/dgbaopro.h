
/* This file was generated automatically by Zephir do not modify it! */

#ifndef ZEPHIR_CLASS_ENTRIES_H
#define ZEPHIR_CLASS_ENTRIES_H

#include "dgbaopro/loader.zep.h"
#include "dgbaopro/vip.zep.h"

#endif